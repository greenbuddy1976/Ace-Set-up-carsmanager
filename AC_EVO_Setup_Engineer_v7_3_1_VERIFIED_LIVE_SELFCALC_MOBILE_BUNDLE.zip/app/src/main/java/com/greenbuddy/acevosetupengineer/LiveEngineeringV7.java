package com.greenbuddy.acevosetupengineer;

import java.util.*;

/** v7.3.1: variant layer derived from the selected car's observed calibration range; no Track-DNA. */
public final class LiveEngineeringV7 {
    private LiveEngineeringV7(){}
    private interface Get{float v(LiveSetupSpec s);}
    private interface Set{void v(LiveSetupSpec s,float x);}
    private static float quantile(VehicleModelStore.Model m,Get g,float q){ArrayList<Float>x=new ArrayList<>();for(LiveSetupSpec s:m.calibration){float v=g.v(s);if(Float.isFinite(v))x.add(v);}if(x.isEmpty())return g.v(m.center);Collections.sort(x);if(x.size()==1)return x.get(0);float p=q*(x.size()-1),f=(float)Math.floor(p),c=(float)Math.ceil(p);int i=(int)f,j=(int)c;if(i==j)return x.get(i);return x.get(i)+(x.get(j)-x.get(i))*(p-i);}
    private static void setQ(LiveSetupSpec s,VehicleModelStore.Model m,Get g,Set set,float q){set.v(s,quantile(m,g,q));}
    public static LiveSetupSpec build(LiveSetupSpec base,String variant,VehicleModelStore.Model model,boolean exact,LiveUpdateManager.LiveState live){
        LiveSetupSpec s=base.copy();s.variant=variant;s.generationMode=exact?"LIVE EXACT":"SELF CALCULATED";s.confidence=exact?"HIGH":(s.trackFusionCars>=2?"DATA-FUSED":"MODEL-ONLY");
        if(model!=null&&!"FAST_CONTROL".equals(variant))applyVariant(s,variant,model);else if(model==null&&!"FAST_CONTROL".equals(variant))s.note="No verified multi-source vehicle model: variant transform withheld; no magic delta substituted.";
        SetupValidator.Result vr=SetupValidator.check(s);s.validation=vr.text();if(!vr.ok)throw new IllegalArgumentException("Plausibility validation failed: "+vr.text());
        EngineeringSelfAuditV73.Result ar=EngineeringSelfAuditV73.verify(base,s,variant,model,exact);s.engineeringAudit=ar.text();if(!ar.ok)throw new IllegalArgumentException("Engineering self-audit failed: "+ar.text());
        if(exact)s.note="Exakte LIVE-Datei für Fahrzeug + Layout wurde binär und per Fahrzeugsignatur akzeptiert. Varianten bleiben innerhalb des für dieses Fahrzeug beobachteten Kalibrierbereichs.";
        else s.note="Kein exact car+layout Setup akzeptiert. Das Setup wird aus einem Multi-Source-Same-Car-Modell berechnet; keine einzelne Quelldatei, Quellstrecke oder Spenderdatei wird ausgewählt. Zielstrecken-Fusion verwendet pro Fahrzeug zuerst den Median mehrerer normalisierter Abweichungen und danach den Median über verschiedene Fahrzeugmodelle. Reifendruck, Fuel und Elektronik werden nicht aus fremden Fahrzeugen übertragen.";
        s.note+=" Reifendruck wird nicht auf einen erfundenen Hot-Target-Wert gesetzt; Hot-Pressure muss nach dem Fahren gemessen und kalibriert werden.";
        if(live!=null&&(live.newerThanEmbedded||live.genericPhysicsChanges))s.note+=" REVIEW REQUIRED: neuer bzw. physikrelevanter Patch erkannt.";return s;
    }
    private static void applyVariant(LiveSetupSpec s,String variant,VehicleModelStore.Model m){
        if("SAFE".equals(variant)){
            for(int i=0;i<4;i++){final int k=i;setQ(s,m,x->x.camber[k],(x,v)->x.camber[k]=v,.75f);}for(int i=2;i<4;i++){final int k=i;setQ(s,m,x->x.toe[k],(x,v)->x.toe[k]=v,.75f);}for(int i=0;i<2;i++){final int k=i;setQ(s,m,x->x.rideHeight[k],(x,v)->x.rideHeight[k]=v,.75f);}if(s.tcPresent)setQ(s,m,x->x.tc,(x,v)->x.tc=v,.75f);if(s.absPresent)setQ(s,m,x->x.abs,(x,v)->x.abs=v,.75f);
        }else if("STABLE_LONGRUN".equals(variant)){
            for(int i=2;i<4;i++){final int k=i;setQ(s,m,x->x.toe[k],(x,v)->x.toe[k]=v,.75f);}if(s.tcPresent)setQ(s,m,x->x.tc,(x,v)->x.tc=v,.75f);if(s.absPresent)setQ(s,m,x->x.abs,(x,v)->x.abs=v,.75f);
        }else if("HOTLAP_ATTACK".equals(variant)){
            for(int i=0;i<4;i++){final int k=i;setQ(s,m,x->x.camber[k],(x,v)->x.camber[k]=v,.25f);}for(int i=0;i<2;i++){final int k=i;setQ(s,m,x->x.toe[k],(x,v)->x.toe[k]=v,.25f);setQ(s,m,x->x.rideHeight[k],(x,v)->x.rideHeight[k]=v,.25f);}if(s.tcPresent)setQ(s,m,x->x.tc,(x,v)->x.tc=v,.25f);
        }else s.variant="FAST_CONTROL";
        // Fuel, pressure and wing remain from the exact/calculated base; no stint/hot-pressure/aero optimum is invented.
    }
}
