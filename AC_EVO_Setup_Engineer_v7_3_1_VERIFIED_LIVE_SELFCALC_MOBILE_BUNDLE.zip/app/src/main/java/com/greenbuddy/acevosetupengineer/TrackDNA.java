package com.greenbuddy.acevosetupengineer;

import org.json.JSONObject;

/** Legacy-compatible custom-track metadata only. No setup calculation uses track DNA values. */
public class TrackDNA {
    public String token="",track="";
    public static TrackDNA fromJson(JSONObject o)throws Exception{TrackDNA d=new TrackDNA();d.token=o.getString("token");d.track=o.getString("track");return d;}
    public JSONObject toJson()throws Exception{JSONObject o=new JSONObject();o.put("token",token);o.put("track",track);return o;}
    public static TrackDNA preset(String token,String name,String ignoredProfile){TrackDNA d=new TrackDNA();d.token=token;d.track=name;return d;}
}
