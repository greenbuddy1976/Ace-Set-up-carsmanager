package com.greenbuddy.acevosetupengineer;

import java.util.*;

/** v7.3.1 logic gate: no Track-DNA, no donor/reference-track requirement, no out-of-range auto edits. */
public final class EngineeringSelfAuditV73 {
    public static final class Result{public boolean ok=true;public final List<String> notes=new ArrayList<>(),errors=new ArrayList<>();public String text(){StringBuilder b=new StringBuilder(ok?"PASS":"FAIL");for(String x:notes)b.append(" | ").append(x);for(String x:errors)b.append(" | ERROR: ").append(x);return b.toString();}}
    private EngineeringSelfAuditV73(){}
    private static void fail(Result r,String x){r.ok=false;r.errors.add(x);}
    private interface Get{float v(LiveSetupSpec s);}
    private static boolean finite(float x){return Float.isFinite(x);}
    private static float min(VehicleModelStore.Model m,Get g){float z=Float.POSITIVE_INFINITY;for(LiveSetupSpec s:m.calibration){float v=g.v(s);if(finite(v))z=Math.min(z,v);}return z;}
    private static float max(VehicleModelStore.Model m,Get g){float z=Float.NEGATIVE_INFINITY;for(LiveSetupSpec s:m.calibration){float v=g.v(s);if(finite(v))z=Math.max(z,v);}return z;}
    private static void inObserved(Result r,String n,float v,VehicleModelStore.Model m,Get g){if(!finite(v))return;if(m==null){fail(r,n+" changed without a verified same-car model");return;}float lo=min(m,g),hi=max(m,g);if(!finite(lo)||!finite(hi)){fail(r,n+" has no verified same-car calibration range");return;}float eps=Math.max(0.001f,Math.abs(hi-lo)*0.00001f);if(v<lo-eps||v>hi+eps)fail(r,n+" outside verified same-car calibration range ["+lo+","+hi+"]");}
    private static void changedGate(Result r,String n,float a,float b,VehicleModelStore.Model m,Get g){if(!finite(a)&&!finite(b))return;if(!finite(a)||!finite(b)||Math.abs(a-b)>0.00001f)inObserved(r,n,b,m,g);}
    private static void calculatedGate(Result r,String n,float v,VehicleModelStore.Model m,Get g,boolean exact){if(!exact&&finite(v))inObserved(r,n,v,m,g);}

    public static Result verify(LiveSetupSpec base,LiveSetupSpec out,String variant,VehicleModelStore.Model model,boolean exact){Result r=new Result();
        if(!Objects.equals(base.carId,out.carId))fail(r,"target car changed");if(!Objects.equals(base.trackToken,out.trackToken))fail(r,"target layout changed");
        for(int i=0;i<4;i++)if(Math.abs(base.pressure[i]-out.pressure[i])>0.0001f)fail(r,"pressure["+i+"] auto-modified");

        // A calculated setup must itself remain inside the selected car's observed calibration envelope.
        calculatedGate(r,"brakeBias",out.brakeBias,model,s->s.brakeBias,exact);calculatedGate(r,"diffPreload",out.diffPreload,model,s->s.diffPreload,exact);
        for(int i=0;i<2;i++){final int k=i;calculatedGate(r,"ARB["+i+"]",out.arb[i],model,s->s.arb[k],exact);calculatedGate(r,"rideHeight["+i+"]",out.rideHeight[i],model,s->s.rideHeight[k],exact);}
        for(int i=0;i<4;i++){final int k=i;calculatedGate(r,"camber["+i+"]",out.camber[i],model,s->s.camber[k],exact);calculatedGate(r,"toe["+i+"]",out.toe[i],model,s->s.toe[k],exact);calculatedGate(r,"spring["+i+"]",out.spring[i],model,s->s.spring[k],exact);calculatedGate(r,"bumpstopRange["+i+"]",out.bumpstopRange[i],model,s->s.bumpstopRange[k],exact);calculatedGate(r,"bumpstopRate["+i+"]",out.bumpstopRate[i],model,s->s.bumpstopRate[k],exact);calculatedGate(r,"slowBump["+i+"]",out.slowBump[i],model,s->s.slowBump[k],exact);calculatedGate(r,"fastBump["+i+"]",out.fastBump[i],model,s->s.fastBump[k],exact);calculatedGate(r,"slowRebound["+i+"]",out.slowRebound[i],model,s->s.slowRebound[k],exact);calculatedGate(r,"fastRebound["+i+"]",out.fastRebound[i],model,s->s.fastRebound[k],exact);}
        if(!exact&&out.tcPresent)inObserved(r,"TC",out.tc,model,s->s.tc);if(!exact&&out.absPresent)inObserved(r,"ABS",out.abs,model,s->s.abs);
        if(!exact&&out.wingVerified&&out.wing!=null)inObserved(r,"wing",out.wing,model,s->s.wing==null?Float.NaN:s.wing);

        // Any post-base variant/fine-tune edit must also be range-gated, including FAST_CONTROL.
        changedGate(r,"brakeBias edit",base.brakeBias,out.brakeBias,model,s->s.brakeBias);changedGate(r,"diffPreload edit",base.diffPreload,out.diffPreload,model,s->s.diffPreload);
        for(int i=0;i<2;i++){final int k=i;changedGate(r,"ARB edit["+i+"]",base.arb[i],out.arb[i],model,s->s.arb[k]);changedGate(r,"rideHeight edit["+i+"]",base.rideHeight[i],out.rideHeight[i],model,s->s.rideHeight[k]);}
        for(int i=0;i<4;i++){final int k=i;changedGate(r,"camber edit["+i+"]",base.camber[i],out.camber[i],model,s->s.camber[k]);changedGate(r,"toe edit["+i+"]",base.toe[i],out.toe[i],model,s->s.toe[k]);changedGate(r,"spring edit["+i+"]",base.spring[i],out.spring[i],model,s->s.spring[k]);changedGate(r,"bumpstopRange edit["+i+"]",base.bumpstopRange[i],out.bumpstopRange[i],model,s->s.bumpstopRange[k]);changedGate(r,"bumpstopRate edit["+i+"]",base.bumpstopRate[i],out.bumpstopRate[i],model,s->s.bumpstopRate[k]);changedGate(r,"slowBump edit["+i+"]",base.slowBump[i],out.slowBump[i],model,s->s.slowBump[k]);changedGate(r,"fastBump edit["+i+"]",base.fastBump[i],out.fastBump[i],model,s->s.fastBump[k]);changedGate(r,"slowRebound edit["+i+"]",base.slowRebound[i],out.slowRebound[i],model,s->s.slowRebound[k]);changedGate(r,"fastRebound edit["+i+"]",base.fastRebound[i],out.fastRebound[i],model,s->s.fastRebound[k]);}
        if(out.tcPresent&&base.tcPresent)changedGate(r,"TC edit",base.tc,out.tc,model,s->s.tc);if(out.absPresent&&base.absPresent)changedGate(r,"ABS edit",base.abs,out.abs,model,s->s.abs);
        if(out.wingVerified&&out.wing!=null&&base.wing!=null)changedGate(r,"wing edit",base.wing,out.wing,model,s->s.wing==null?Float.NaN:s.wing);

        SetupValidator.Result v=SetupValidator.check(out);if(!v.ok)fail(r,"SetupValidator: "+v.text());r.notes.add("pressure unchanged");r.notes.add(exact?"LIVE exact binary; automatic edits same-car range-gated":"self-calculated same-car model; all editable fields range-gated; no donor/reference track");return r;
    }
    public static Result verifyFamily(Map<String,LiveSetupSpec> m){Result r=new Result();LiveSetupSpec safe=m.get("SAFE"),stable=m.get("STABLE_LONGRUN"),fast=m.get("FAST_CONTROL"),hot=m.get("HOTLAP_ATTACK");if(safe==null||stable==null||fast==null||hot==null){fail(r,"variant family incomplete");return r;}for(LiveSetupSpec x:new LiveSetupSpec[]{stable,fast,hot}){if(!Objects.equals(safe.carId,x.carId))fail(r,"car mismatch");if(!Objects.equals(safe.trackToken,x.trackToken))fail(r,"layout mismatch");if(!Objects.equals(safe.sourceSha256,x.sourceSha256))fail(r,"source/model hash mismatch");for(int i=0;i<4;i++)if(Math.abs(safe.pressure[i]-x.pressure[i])>0.0001f)fail(r,"pressure mismatch wheel "+i);}r.notes.add("4/4 same car/layout/source; pressure family identical");return r;}
}
