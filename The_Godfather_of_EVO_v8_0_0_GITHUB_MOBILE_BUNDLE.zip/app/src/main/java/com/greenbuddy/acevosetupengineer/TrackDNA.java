package com.greenbuddy.acevosetupengineer;

import org.json.JSONObject;

/** Technical description of the SELECTED track/layout. Never used to choose a donor track. */
public class TrackDNA {
    public String token="",track="";
    public int roughness=5,highSpeed=6,drag=6,braking=6,traction=6,kerb=5,rotation=6;
    public static TrackDNA fromJson(JSONObject o)throws Exception{TrackDNA d=new TrackDNA();d.token=o.getString("token");d.track=o.getString("track");d.roughness=o.getInt("roughness");d.highSpeed=o.getInt("highSpeed");d.drag=o.getInt("drag");d.braking=o.getInt("braking");d.traction=o.getInt("traction");d.kerb=o.getInt("kerb");d.rotation=o.getInt("rotation");return d;}
    public JSONObject toJson()throws Exception{JSONObject o=new JSONObject();o.put("token",token);o.put("track",track);o.put("roughness",roughness);o.put("highSpeed",highSpeed);o.put("drag",drag);o.put("braking",braking);o.put("traction",traction);o.put("kerb",kerb);o.put("rotation",rotation);return o;}
    public static TrackDNA preset(String token,String name,String profile){TrackDNA d=new TrackDNA();d.token=token;d.track=name;if("Highspeed".equals(profile)){d.roughness=4;d.highSpeed=9;d.drag=9;d.braking=7;d.traction=5;d.kerb=4;d.rotation=4;}else if("Technisch".equals(profile)){d.roughness=5;d.highSpeed=5;d.drag=4;d.braking=7;d.traction=8;d.kerb=6;d.rotation=8;}else if("Bumpy / Nordschleife".equals(profile)){d.roughness=9;d.highSpeed=8;d.drag=6;d.braking=8;d.traction=8;d.kerb=8;d.rotation=7;}else if("Stop & Go".equals(profile)){d.roughness=5;d.highSpeed=4;d.drag=4;d.braking=9;d.traction=9;d.kerb=6;d.rotation=7;}return d;}
}
