#!/usr/bin/env python3
from urllib.request import Request,urlopen
from urllib.parse import urljoin
import re,time,zipfile,io,sys
UA='Mozilla/5.0 AC-EVO-Setup-Engineer-v7.3.1-GitHub-Verification'
def fetch(url,limit,tries=3):
    last=None
    for i in range(tries):
        try:
            r=urlopen(Request(url,headers={'User-Agent':UA,'Cache-Control':'no-cache','Pragma':'no-cache','Accept-Language':'en-US,en;q=0.8'}),timeout=30)
            if getattr(r,'status',200)<200 or getattr(r,'status',200)>=300: raise RuntimeError('HTTP '+str(r.status))
            b=r.read(limit+1)
            if len(b)>limit: raise RuntimeError('download too large')
            return b,r.geturl()
        except Exception as e:
            last=e
            if i+1<tries: time.sleep(2*(i+1))
    raise last

def strip_html(s):
    s=re.sub(r'(?is)<script.*?</script>',' ',s);s=re.sub(r'(?is)<style.*?</style>',' ',s);s=re.sub(r'(?is)<[^>]+>',' ',s)
    return s.replace('&nbsp;',' ').replace('&amp;','&').replace('&middot;','·').replace('&#183;','·')

# SetupsMarket completeness / structure
home,_=fetch('https://setupsmarket.com/',8*1024*1024)
h=home.decode('utf-8','replace');plain=strip_html(h)
m=re.search(r'(?i)(\d{1,5})\s+Setups\b',plain)
if not m: raise RuntimeError('SetupsMarket setup count not found')
expected=int(m.group(1)); ids=[];seen=set()
for x in re.findall(r'(?:https?://(?:www\.)?setupsmarket\.com)?/?setup/([0-9a-fA-F-]{36})',h,re.I):
    x=x.lower()
    if x not in seen:seen.add(x);ids.append(x)
if expected<=0 or len(ids)<expected: raise RuntimeError(f'SetupsMarket coverage incomplete: discovered={len(ids)} expected={expected}')
if not ids: raise RuntimeError('SetupsMarket no setup UUIDs')
detail,_=fetch('https://setupsmarket.com/setup/'+ids[0],2*1024*1024)
dp=strip_html(detail.decode('utf-8','replace'))
if '·' not in dp or not re.search(r'(?i)game\s*v?[0-9]+(?:\.[0-9]+)+',dp): raise RuntimeError('SetupsMarket structured detail metadata format unavailable')

# RacePlace baseline discovery + archive coverage
rp,_=fetch('https://raceplace.racing/downloads/',2*1024*1024)
rh=rp.decode('utf-8','replace').replace('&amp;','&')
link=None
for mm in re.finditer(r'href\s*=\s*["\']([^"\']*/download/\d+/[^"\']*)["\']',rh,re.I):
    a=max(0,mm.start()-900);b=min(len(rh),mm.end()+1600);ctx=rh[a:b].lower()
    if 'raceplace-ace-baseline-setups' in ctx or 'assetto corsa evo free baseline setups' in ctx:
        link=urljoin('https://raceplace.racing/downloads/',mm.group(1));break
if not link: raise RuntimeError('RacePlace AC EVO baseline link not found')
zbytes,_=fetch(link,25*1024*1024)
try:
    z=zipfile.ZipFile(io.BytesIO(zbytes)); setups=[n for n in z.namelist() if n.lower().endswith('.carsetup')]
except Exception as e: raise RuntimeError('RacePlace baseline is not a readable ZIP: '+str(e))
if not setups: raise RuntimeError('RacePlace baseline contains no .carsetup')
print(f'LIVE_SOURCE_SMOKE_PASS setupsmarket={len(ids)}/{expected} raceplace_carsetup={len(setups)}')
