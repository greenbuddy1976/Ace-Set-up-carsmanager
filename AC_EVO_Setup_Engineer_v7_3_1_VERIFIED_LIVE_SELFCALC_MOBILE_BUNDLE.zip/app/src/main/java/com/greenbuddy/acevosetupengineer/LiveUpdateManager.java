package com.greenbuddy.acevosetupengineer;

import android.os.Handler;
import android.os.Looper;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class LiveUpdateManager {
    public static final String EMBEDDED_VERSION="0.8.1";
    private static final String PATCH_INDEX="https://support.505games.com/support/solutions/folders/150000543169";
    private static final String FORUM="https://www.assettocorsa.net/forum/index.php?forums/news-and-announcements.61/";
    private static final String STEAM="https://store.steampowered.com/app/3058630/Assetto_Corsa_EVO/?l=english";
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());

    public interface Callback { void done(LiveState state); }
    public static class LiveState {
        public boolean online,newerThanEmbedded,genericPhysicsChanges,mustangSpecific,dallaraSpecific;
        public String version="",checkedAt="",status="",sourceNote="",patchUrl="";
        public String compact(){return (online?"LIVE":"OFFLINE")+" · AC EVO "+version+(newerThanEmbedded?" · NEUER ALS APP":"")+
                (mustangSpecific?" · MUSTANG ERWÄHNT":"")+(dallaraSpecific?" · DALLARA ERWÄHNT":"");}
    }
    public void check(Callback cb){
        executor.execute(()->{
            LiveState s=new LiveState();s.checkedAt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.GERMANY).format(new Date());
            try{
                String index=safeFetch(PATCH_INDEX),forum=safeFetch(FORUM),steam=safeFetch(STEAM);
                String all=index+" "+forum+" "+steam;
                s.version=highestVersion(all);if(s.version.isEmpty())s.version=EMBEDDED_VERSION;
                s.online=!(index.isEmpty()&&forum.isEmpty()&&steam.isEmpty());
                s.patchUrl=findPatchUrl(index,s.version);
                String patch=s.patchUrl.isEmpty()?index:safeFetch(s.patchUrl);
                String p=stripHtml(patch).toLowerCase(Locale.ROOT);
                s.mustangSpecific=p.contains("mustang");s.dallaraSpecific=p.contains("dallara");
                s.genericPhysicsChanges=p.contains("physics")||p.contains("handling")||p.contains("tyre")||p.contains("tire")||p.contains("suspension");
                s.newerThanEmbedded=compareVersions(s.version,EMBEDDED_VERSION)>0;
                if(s.newerThanEmbedded)s.status="Neuer Patch erkannt. v7 übernimmt KEINE unbekannte Physikrichtung automatisch; Setup wird als REVIEW REQUIRED markiert.";
                else if(s.mustangSpecific||s.dallaraSpecific)s.status="Aktuellster erkannter Patch erwähnt ein unterstütztes Fahrzeug: REVIEW REQUIRED.";
                else s.status="Versionscheck OK. Patchstand geprüft. Setupdaten werden separat LIVE aus der exakten RacePlace/DTVR-Datei geladen; Patchtext ersetzt keine Telemetrie.";
                s.sourceNote="Live-Quellen: offizieller 505-Games Patch-Index + Kunos News + Steam. Patch-Artikel wird dynamisch aus dem Index gewählt.";
            }catch(Exception e){s.online=false;s.version=EMBEDDED_VERSION;s.status="PATCH CHECK fehlgeschlagen; Versionsanzeige fällt auf App-Prüfstand "+EMBEDDED_VERSION+" zurück. FIXED FALLBACK nutzt die feste verifizierte Same-Car-Basisdatei: "+e.getMessage();s.sourceNote="OFFLINE Patchcheck: exakte LIVE-Quelle ist optional; FIXED FALLBACK bleibt deterministisch und Same-Car-only.";}
            LiveState out=s;main.post(()->cb.done(out));
        });
    }
    private static String findPatchUrl(String html,String version){
        if(html==null||html.isEmpty())return "";
        Pattern p=Pattern.compile("href=[\\\"']([^\\\"']*support/solutions/articles/[^\\\"']+)[\\\"'][^>]*>[^<]*(?:AC\\s*EVO|Assetto\\s*Corsa\\s*EVO)[^<]*"+Pattern.quote(version),Pattern.CASE_INSENSITIVE);
        Matcher m=p.matcher(html);if(m.find())return absolute(m.group(1));
        Pattern p2=Pattern.compile("href=[\\\"']([^\\\"']*solutions/articles/[^\\\"']*"+version.replace(".","[-_.]?")+"[^\\\"']*)[\\\"']",Pattern.CASE_INSENSITIVE);
        m=p2.matcher(html);return m.find()?absolute(m.group(1)):"";
    }
    private static String absolute(String u){if(u.startsWith("http"))return u;if(u.startsWith("/"))return "https://support.505games.com"+u;return "https://support.505games.com/"+u;}
    private static String safeFetch(String url){try{return fetch(url);}catch(Exception e){return "";}}
    private static String fetch(String u)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(9000);c.setReadTimeout(12000);c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent","Mozilla/5.0 Android AC-EVO-Setup-Engineer-v7-FINAL/7.1");c.setRequestProperty("Accept-Language","en-US,en;q=0.8");
        int code=c.getResponseCode();InputStream in=(code>=200&&code<400)?c.getInputStream():c.getErrorStream();if(in==null)throw new IOException("HTTP "+code);
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n,total=0;while((n=in.read(b))>0&&total<2_000_000){out.write(b,0,n);total+=n;}in.close();c.disconnect();
        if(code<200||code>=400)throw new IOException("HTTP "+code);return out.toString(StandardCharsets.UTF_8.name());
    }
    private static String stripHtml(String s){return s.replaceAll("(?is)<script.*?</script>"," ").replaceAll("(?is)<style.*?</style>"," ").replaceAll("(?is)<[^>]+>"," ").replace("&nbsp;"," ").replace("&amp;","&");}
    private static String highestVersion(String html){
        Matcher m=Pattern.compile("(?:AC\\s*EVO|Assetto\\s*Corsa\\s*EVO)[^0-9]{0,30}([0-9]+(?:\\.[0-9]+){1,3})",Pattern.CASE_INSENSITIVE).matcher(stripHtml(html));
        String best="";while(m.find())if(best.isEmpty()||compareVersions(m.group(1),best)>0)best=m.group(1);return best;
    }
    public static int compareVersions(String a,String b){String[] aa=a.split("\\."),bb=b.split("\\.");int n=Math.max(aa.length,bb.length);for(int i=0;i<n;i++){int x=i<aa.length?num(aa[i]):0,y=i<bb.length?num(bb[i]):0;if(x!=y)return Integer.compare(x,y);}return 0;}
    private static int num(String s){try{return Integer.parseInt(s.replaceAll("[^0-9]",""));}catch(Exception e){return 0;}}
}
