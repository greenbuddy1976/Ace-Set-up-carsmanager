package com.greenbuddy.acevosetupengineer;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

/** Pure-Java structured metadata matcher used by the LIVE source scanner and runtime regression tests. */
public final class SetupMetadataMatcher {
    private SetupMetadataMatcher(){}
    public static String normalize(String s){
        String x=Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);
        return x.replaceAll("[^a-z0-9]+","");
    }
    public static int trackScore(String normalized,List<String> aliases,List<String> rejects){
        String n=normalized==null?"":normalized;
        if(rejects!=null)for(String bad:rejects){String b=normalize(bad);if(!b.isEmpty()&&n.contains(b))return -1;}
        int score=-1;
        if(aliases!=null)for(String alias:aliases){String a=normalize(alias);if(!a.isEmpty()&&n.contains(a))score=Math.max(score,100+a.length());}
        return score;
    }
    /**
     * Reads only the structured metadata row `Car · Track · ...`.
     * A free-text title is deliberately not inspected, so a title saying "Bathurst"
     * cannot override structured metadata saying "Brands Hatch GP".
     */
    public static int structuredTrackScore(String plain,String carName,List<String> aliases,List<String> rejects){
        if(plain==null||carName==null||carName.trim().isEmpty())return -1;
        String q=Pattern.quote(carName.trim());
        Pattern p=Pattern.compile("(?i)"+q+"\\s*·\\s*([^·\\r\\n]{1,140}?)\\s*·");
        Matcher m=p.matcher(plain);int best=-1;
        while(m.find()){
            String track=m.group(1).replaceAll("⏱.*$","").trim();
            best=Math.max(best,trackScore(normalize(track),aliases,rejects));
        }
        return best;
    }
}
