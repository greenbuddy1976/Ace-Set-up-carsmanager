package com.greenbuddy.acevosetupengineer;

import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/**
 * Conservative AC EVO .carsetup protobuf decoder/writer.
 * Only common fields that were cross-checked on supplied genuine files are edited.
 * Unknown fields are preserved byte-for-byte structurally.
 */
public final class LiveCarSetupCodec {
    private LiveCarSetupCodec(){}

    private static final Map<String,String[]> SIGNATURES=new LinkedHashMap<>();
    static {
        SIGNATURES.put("ford_mustang_gt3",new String[]{"ks_ford_mustang_gt3_preset_msggt3_mech_1_preset_msggt3_visual_1","ks_ford_mustang_gt3_preset_msg"});
        SIGNATURES.put("dallara_exp",new String[]{"ks_dallara_exp_preset_dalexp_mech_1_preset_dalexp_visual_1"});
        SIGNATURES.put("audi_r8_lms_gt3_evo_ii",new String[]{"ks_audi_r8_lms_gt3_evo_2_preset_r8gt3_mech_1_preset_r8gt3_visual_1"});
        SIGNATURES.put("bmw_m4_gt3_evo",new String[]{"ks_bmw_m4_gt3_preset_m4gt3_mech_1_preset_m4gt3_visual_1"});
        SIGNATURES.put("ferrari_296_gt3",new String[]{"ks_ferrari_296_gt3_preset_296gt3_mech_1_preset_296gt3_visual_1"});
        SIGNATURES.put("porsche_992_gt3_r_rennsport",new String[]{"ks_porsche_992_gt3_r_rennsport_preset_992ren_mech_1_preset_992ren_visual_1"});
    }

    private static class Field {int n,w; long varint; byte[] raw; Msg child;Field(int n,int w){this.n=n;this.w=w;}}
    private static class Msg {
        final List<Field> fields=new ArrayList<>();
        static Msg parse(byte[] data)throws Exception{
            Msg m=new Msg();int[] p={0};while(p[0]<data.length){long key=readVarint(data,p);int n=(int)(key>>>3),w=(int)(key&7);if(n<=0||(w!=0&&w!=1&&w!=2&&w!=5))throw new IOException("Invalid protobuf field");Field f=new Field(n,w);
                if(w==0)f.varint=readVarint(data,p);else if(w==1)f.raw=take(data,p,8);else if(w==5)f.raw=take(data,p,4);else{int len=(int)readVarint(data,p);byte[] x=take(data,p,len);f.raw=x;try{Msg c=parse(x);if(!c.fields.isEmpty())f.child=c;}catch(Exception ignored){}}m.fields.add(f);}return m;
        }
        byte[] encode()throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();for(Field f:fields){writeVarint(out,((long)f.n<<3)|f.w);if(f.w==0)writeVarint(out,f.varint);else if(f.w==1||f.w==5)out.write(f.raw);else{byte[] x=f.child!=null?f.child.encode():f.raw;writeVarint(out,x.length);out.write(x);}}return out.toByteArray();}
        Msg message(int fieldNo,int occurrence)throws Exception{int seen=0;for(Field f:fields)if(f.n==fieldNo&&f.w==2&&f.child!=null){if(seen++==occurrence)return f.child;}throw new IOException("Message "+fieldNo+"["+occurrence+"] missing");}
        boolean hasFloat(int fieldNo){for(Field f:fields)if(f.n==fieldNo&&f.w==5)return true;return false;}
        Float getFloatOrNull(int fieldNo){for(Field f:fields)if(f.n==fieldNo&&f.w==5&&f.raw!=null&&f.raw.length==4)return ByteBuffer.wrap(f.raw).order(ByteOrder.LITTLE_ENDIAN).getFloat();return null;}
        float requireFloat(int fieldNo,String label)throws IOException{Float f=getFloatOrNull(fieldNo);if(f==null)throw new IOException(label+" field missing");return f;}
        void setFloat(int fieldNo,float value){for(Field f:fields)if(f.n==fieldNo&&f.w==5){f.raw=f32(value);return;}Field nf=new Field(fieldNo,5);nf.raw=f32(value);int at=fields.size();for(int i=0;i<fields.size();i++)if(fields.get(i).n>fieldNo){at=i;break;}fields.add(at,nf);}
        void setFloatOnlyIfPresent(int fieldNo,float value){for(Field f:fields)if(f.n==fieldNo&&f.w==5){f.raw=f32(value);return;}}
        boolean hasPackedFloats(int fieldNo){for(Field f:fields)if(f.n==fieldNo&&f.w==2&&f.raw!=null&&f.raw.length>=4&&f.raw.length%4==0)return true;return false;}
        float[] getPackedFloats(int fieldNo){
            for(Field f:fields)if(f.n==fieldNo&&f.w==2&&f.raw!=null&&f.raw.length>=4&&f.raw.length%4==0){
                float[] x=new float[f.raw.length/4];ByteBuffer bb=ByteBuffer.wrap(f.raw).order(ByteOrder.LITTLE_ENDIAN);for(int i=0;i<x.length;i++)x[i]=bb.getFloat();return x;
            }
            return null;
        }
        void setPackedFloatOnlyIfPresent(int fieldNo,int index,float value){
            for(Field f:fields)if(f.n==fieldNo&&f.w==2&&f.raw!=null&&f.raw.length%4==0){int n=f.raw.length/4;if(index<0||index>=n)return;byte[] z=f.raw.clone();ByteBuffer.wrap(z).order(ByteOrder.LITTLE_ENDIAN).putFloat(index*4,value);f.raw=z;f.child=null;return;}
        }
    }


    public static final class StructureInfo {
        public boolean diffPreload=false,arb=false,tc=false,tc2=false,abs=false,wing=false;
        public final boolean[] spring={false,false,false,false},bumpstopRange={false,false,false,false},bumpstopRate={false,false,false,false};
        public final boolean[] slowBump={false,false,false,false},fastBump={false,false,false,false},slowRebound={false,false,false,false},fastRebound={false,false,false,false};
        public String summary(){int optional=0;if(diffPreload)optional++;if(arb)optional+=2;if(tc)optional++;if(tc2)optional++;if(abs)optional++;if(wing)optional++;for(int i=0;i<4;i++){if(spring[i])optional++;if(bumpstopRange[i])optional++;if(bumpstopRate[i])optional++;if(slowBump[i])optional++;if(fastBump[i])optional++;if(slowRebound[i])optional++;if(fastRebound[i])optional++;}return "mandatory=21 optional="+optional;}
    }

    /**
     * Structure-only inspection: checks field presence and vehicle signature, but does not decode
     * any stored setup number into the self-calculation model.
     */
    public static StructureInfo inspectStructure(byte[] source,String carId,String signature)throws Exception{
        if(source==null||source.length<100||source.length>2_000_000)throw new IOException("Invalid structure template size");
        if(!signatureMatches(source,carId,signature))throw new IOException("Structure template car signature mismatch");
        Msg top=Msg.parse(source);StructureInfo i=new StructureInfo();Msg mech=top.message(1,0);
        // mandatory structural paths; values intentionally not read
        mech.message(3,0);Msg diff=mech.message(4,0);i.diffPreload=diff.hasFloat(3);i.arb=mech.hasPackedFloats(1);
        for(int k=0;k<4;k++){Msg susp=top.message(2,k);i.spring[k]=susp.hasFloat(1);try{Msg bs=susp.message(2,0);i.bumpstopRange[k]=bs.hasFloat(1);i.bumpstopRate[k]=bs.hasFloat(2);}catch(Exception ignored){}
            Msg dam=top.message(3,k);i.slowBump[k]=dam.hasFloat(1);i.fastBump[k]=dam.hasFloat(2);i.slowRebound[k]=dam.hasFloat(3);i.fastRebound[k]=dam.hasFloat(4);
            Msg tyre=top.message(4,k);if(!tyre.hasFloat(1)||!tyre.hasFloat(2)||!tyre.hasFloat(3))throw new IOException("Mandatory tyre fields missing at wheel "+k);
        }
        Msg elec=top.message(5,0);i.tc=elec.hasFloat(1);i.tc2=elec.hasFloat(2);i.abs=elec.hasFloat(3);Msg aero=top.message(6,0);if(!aero.hasFloat(2)||!aero.hasFloat(3))throw new IOException("Mandatory ride-height fields missing");i.wing=aero.hasFloat(5);Msg fuel=top.message(7,0);if(!fuel.hasFloat(1))throw new IOException("Mandatory fuel field missing");return i;
    }

    public static boolean isKnownCar(String carId){return SIGNATURES.containsKey(carId);}
    public static String identifyKnownCar(byte[] source){if(source==null)return "";for(String id:SIGNATURES.keySet())if(signatureMatches(source,id))return id;return "";}
    public static String knownPrimarySignature(String carId){String[] x=SIGNATURES.get(carId);return x==null||x.length==0?"":x[0];}
    public static String extractCarSignature(byte[] source){
        if(source==null)return "";String ascii=new String(source,StandardCharsets.ISO_8859_1);
        Matcher strict=Pattern.compile("ks_[A-Za-z0-9_]+_preset_[A-Za-z0-9_]+_mech_[0-9]+_preset_[A-Za-z0-9_]+_visual_[0-9]+").matcher(ascii);
        if(strict.find())return strict.group();
        Matcher loose=Pattern.compile("ks_[A-Za-z0-9_]{8,180}").matcher(ascii);String best="";while(loose.find()){String x=loose.group();int p=x.indexOf("_preset_");if(p>=0&&x.length()>best.length())best=x;}return best;
    }
    public static boolean signatureMatches(byte[] source,String carId){String[] sigs=SIGNATURES.get(carId);if(sigs==null||source==null)return false;String ascii=new String(source,StandardCharsets.ISO_8859_1);for(String s:sigs)if(ascii.contains(s))return true;return false;}
    public static boolean signatureMatches(byte[] source,String carId,String explicitSignature){
        if(signatureMatches(source,carId))return true;if(explicitSignature==null||explicitSignature.trim().isEmpty()||source==null)return false;return new String(source,StandardCharsets.ISO_8859_1).contains(explicitSignature);
    }

    public static LiveSetupSpec decodeGeneric(byte[] source,String label)throws Exception{return decodeInternal(source,"",label,"",false);}
    public static LiveSetupSpec decode(byte[] source,String carId,String carName,String signature)throws Exception{return decodeInternal(source,carId,carName,signature,true);}
    private static LiveSetupSpec decodeInternal(byte[] source,String carId,String carName,String signature,boolean verify)throws Exception{
        if(source==null||source.length<100||source.length>2_000_000)throw new IOException("Invalid .carsetup size");if(verify&&!signatureMatches(source,carId,signature))throw new IOException("Binary car signature does not match "+carName);Msg top=Msg.parse(source);LiveSetupSpec s=new LiveSetupSpec();s.carId=carId;s.carName=carName;
        Msg mech=top.message(1,0);s.brakeBias=mech.message(3,0).requireFloat(1,"Brake bias");
        Float dp=mech.message(4,0).getFloatOrNull(3);s.diffPreload=dp==null?Float.NaN:dp;
        float[] arbs=mech.getPackedFloats(1);if(arbs!=null&&arbs.length>=2){s.arb[0]=arbs[0];s.arb[1]=arbs[1];}
        for(int i=0;i<4;i++){
            Msg susp=top.message(2,i);Float sp=susp.getFloatOrNull(1);if(sp!=null)s.spring[i]=sp;try{Msg bs=susp.message(2,0);Float br=bs.getFloatOrNull(1),bt=bs.getFloatOrNull(2);if(br!=null)s.bumpstopRange[i]=br;if(bt!=null)s.bumpstopRate[i]=bt;}catch(Exception ignored){}
            Msg dam=top.message(3,i);Float a=dam.getFloatOrNull(1),b=dam.getFloatOrNull(2),c=dam.getFloatOrNull(3),d=dam.getFloatOrNull(4);if(a!=null)s.slowBump[i]=a;if(b!=null)s.fastBump[i]=b;if(c!=null)s.slowRebound[i]=c;if(d!=null)s.fastRebound[i]=d;
            Msg tyre=top.message(4,i);s.pressure[i]=tyre.requireFloat(1,"Tyre pressure");s.camber[i]=tyre.requireFloat(2,"Camber");s.toe[i]=tyre.requireFloat(3,"Toe");
        }
        Msg elec=top.message(5,0);Float tc=elec.getFloatOrNull(1);s.tcPresent=tc!=null;s.tc=tc==null?0f:tc;s.tc2=elec.getFloatOrNull(2);Float abs=elec.getFloatOrNull(3);s.absPresent=abs!=null;s.abs=abs==null?0f:abs;
        Msg aero=top.message(6,0);s.rideHeight[0]=aero.requireFloat(2,"Front ride height");s.rideHeight[1]=aero.requireFloat(3,"Rear ride height");if(aero.hasFloat(5)){s.wing=aero.getFloatOrNull(5);s.wingVerified=true;}s.fuel=top.message(7,0).requireFloat(1,"Fuel");return s;
    }

    public static byte[] patch(byte[] source,LiveSetupSpec s,String signature)throws Exception{
        if(source==null)throw new IOException("No source template");if(!signatureMatches(source,s.carId,signature)&&isKnownCar(s.carId))throw new IOException("Source signature changed or wrong car");
        // For user cars without an extractable signature, the exact user-assigned source bytes are still accepted,
        // but the common protobuf structure must decode successfully before and after writing.
        if(!isKnownCar(s.carId)&&signature!=null&&!signature.isEmpty()&&!signatureMatches(source,s.carId,signature))throw new IOException("User-car signature mismatch");
        Msg top=Msg.parse(source);Msg mech=top.message(1,0);mech.message(3,0).setFloat(1,s.brakeBias);if(Float.isFinite(s.diffPreload))mech.message(4,0).setFloatOnlyIfPresent(3,s.diffPreload);for(int i=0;i<2;i++)if(Float.isFinite(s.arb[i]))mech.setPackedFloatOnlyIfPresent(1,i,s.arb[i]);
        for(int i=0;i<4;i++){
            Msg susp=top.message(2,i);if(Float.isFinite(s.spring[i]))susp.setFloatOnlyIfPresent(1,s.spring[i]);try{Msg bs=susp.message(2,0);if(Float.isFinite(s.bumpstopRange[i]))bs.setFloatOnlyIfPresent(1,s.bumpstopRange[i]);if(Float.isFinite(s.bumpstopRate[i]))bs.setFloatOnlyIfPresent(2,s.bumpstopRate[i]);}catch(Exception ignored){}
            Msg dam=top.message(3,i);if(Float.isFinite(s.slowBump[i]))dam.setFloatOnlyIfPresent(1,s.slowBump[i]);if(Float.isFinite(s.fastBump[i]))dam.setFloatOnlyIfPresent(2,s.fastBump[i]);if(Float.isFinite(s.slowRebound[i]))dam.setFloatOnlyIfPresent(3,s.slowRebound[i]);if(Float.isFinite(s.fastRebound[i]))dam.setFloatOnlyIfPresent(4,s.fastRebound[i]);
            Msg tyre=top.message(4,i);tyre.setFloat(1,s.pressure[i]);tyre.setFloat(2,s.camber[i]);tyre.setFloat(3,s.toe[i]);
        }
        Msg elec=top.message(5,0);if(s.tcPresent)elec.setFloatOnlyIfPresent(1,s.tc);if(s.tc2!=null)elec.setFloatOnlyIfPresent(2,s.tc2);if(s.absPresent)elec.setFloatOnlyIfPresent(3,s.abs);Msg aero=top.message(6,0);aero.setFloat(2,s.rideHeight[0]);aero.setFloat(3,s.rideHeight[1]);if(s.wingVerified&&s.wing!=null)aero.setFloatOnlyIfPresent(5,s.wing);top.message(7,0).setFloat(1,s.fuel);byte[] out=top.encode();Msg.parse(out);
        if(isKnownCar(s.carId)&&!signatureMatches(out,s.carId,signature))throw new IOException("Car signature lost after write");if(!isKnownCar(s.carId)&&signature!=null&&!signature.isEmpty()&&!signatureMatches(out,s.carId,signature))throw new IOException("User-car signature lost after write");return out;
    }


    public static void verifyRoundTrip(byte[] data,LiveSetupSpec expected,String signature)throws Exception{
        if(data==null||expected==null)throw new IOException("Roundtrip input missing");LiveSetupSpec got=decode(data,expected.carId,expected.carName,signature);
        for(int i=0;i<4;i++){same("pressure["+i+"]",expected.pressure[i],got.pressure[i],0.0002f);same("camber["+i+"]",expected.camber[i],got.camber[i],0.0002f);same("toe["+i+"]",expected.toe[i],got.toe[i],0.0002f);optSame("spring["+i+"]",expected.spring[i],got.spring[i],0.01f);optSame("bumpstopRange["+i+"]",expected.bumpstopRange[i],got.bumpstopRange[i],0.00001f);optSame("bumpstopRate["+i+"]",expected.bumpstopRate[i],got.bumpstopRate[i],0.01f);optSame("slowBump["+i+"]",expected.slowBump[i],got.slowBump[i],0.01f);optSame("fastBump["+i+"]",expected.fastBump[i],got.fastBump[i],0.01f);optSame("slowRebound["+i+"]",expected.slowRebound[i],got.slowRebound[i],0.01f);optSame("fastRebound["+i+"]",expected.fastRebound[i],got.fastRebound[i],0.01f);}
        for(int i=0;i<2;i++)optSame("ARB["+i+"]",expected.arb[i],got.arb[i],0.01f);optSame("diffPreload",expected.diffPreload,got.diffPreload,0.01f);same("rideHeightF",expected.rideHeight[0],got.rideHeight[0],0.0002f);same("rideHeightR",expected.rideHeight[1],got.rideHeight[1],0.0002f);same("brakeBias",expected.brakeBias,got.brakeBias,0.0002f);same("fuel",expected.fuel,got.fuel,0.0002f);
        if(expected.tcPresent)same("TC",expected.tc,got.tc,0.0002f);if(expected.tc2!=null){if(got.tc2==null)throw new IOException("Roundtrip TC2 missing");same("TC2",expected.tc2,got.tc2,0.0002f);}if(expected.absPresent)same("ABS",expected.abs,got.abs,0.0002f);if(expected.wingVerified&&expected.wing!=null){if(got.wing==null)throw new IOException("Roundtrip wing missing");same("Wing",expected.wing,got.wing,0.0002f);}
    }
    private static void same(String n,float a,float b,float eps)throws IOException{if(!Float.isFinite(a)||!Float.isFinite(b)||Math.abs(a-b)>eps)throw new IOException("Roundtrip mismatch "+n+": "+a+" != "+b);}
    private static void optSame(String n,float a,float b,float eps)throws IOException{if(Float.isNaN(a))return;same(n,a,b,eps);}

    private static byte[] f32(float v){return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(v).array();}
    private static byte[] take(byte[] d,int[] p,int n)throws IOException{if(n<0||p[0]+n>d.length)throw new IOException("Unexpected EOF");byte[] x=Arrays.copyOfRange(d,p[0],p[0]+n);p[0]+=n;return x;}
    private static long readVarint(byte[] d,int[] p)throws IOException{long v=0;int sh=0;while(p[0]<d.length&&sh<64){int b=d[p[0]++]&255;v|=(long)(b&127)<<sh;if((b&128)==0)return v;sh+=7;}throw new IOException("Bad varint");}
    private static void writeVarint(ByteArrayOutputStream o,long v){while((v&~0x7fL)!=0){o.write((int)((v&0x7f)|0x80));v>>>=7;}o.write((int)v);}
}
