package com.greenbuddy.acevosetupengineer;

/** Dimensionless vehicle characteristics used by the donor-free physics calculator. */
public final class VehicleEngineeringProfile {
    public final String carId,carName,category;
    public final float frontBalance,stiffness,aero,traction,rotation,brakingStability;
    public VehicleEngineeringProfile(String id,String name,String cat,float fb,float stiff,float ae,float tr,float rot,float bs){
        carId=id;carName=name;category=cat;frontBalance=fb;stiffness=stiff;aero=ae;traction=tr;rotation=rot;brakingStability=bs;
    }
    public boolean prototype(){return "PROTOTYPE".equals(category);}
}
