# The Godfather of EVO — Assetto Corsa EVO Setup Engineer

© Greenbuddy1976

## Verbindliche Entscheidungslogik

1. Für das exakt ausgewählte Fahrzeug und das exakt ausgewählte Layout wird immer zuerst LIVE gesucht.
2. Bei technischem LIVE-Fehler wird der komplette LIVE-Suchlauf wiederholt: maximal 3 vollständige Versuche.
3. Ein verifiziertes EXACT wird nur übernommen, wenn Fahrzeug, Layout, Binärsignatur und Decoderprüfung passen. Danach darf es als verifizierter Exact-Cache gespeichert werden.
4. Wenn ein vollständiger LIVE-Suchlauf erfolgreich war und kein verifiziertes EXACT gefunden wurde, wird das Setup vollständig neu berechnet.
5. Wenn alle 3 LIVE-Versuche technisch scheitern, wird ausdrücklich `LIVE-SUCHE FEHLGESCHLAGEN NACH 3 VERSUCHEN` gemeldet. Das ist kein Beweis dafür, dass kein Exact existiert. Ein bereits verifizierter Exact-Cache für exakt Auto + Layout darf mit Warnhinweis verwendet werden; andernfalls bleibt SELF CALC klar als LIVE-UNVERIFIED gekennzeichnet.

## Self-Calc — harte Trennung von Struktur und Werten

SELF CALC verwendet ausschließlich:

- das Engineering-/Parameterprofil des ausgewählten Fahrzeugs,
- das Engineeringprofil des ausgewählten Tracks/Layouts,
- die gewünschte Variante.

Die sechs eingebetteten `.carsetup`-Dateien sind ausschließlich Binär-Strukturträger. Sie bestimmen, welche bekannten Felder das jeweilige Fahrzeug tatsächlich besitzt. Ihre gespeicherten Setup-Zahlen werden nicht in die Self-Calc-Berechnung eingelesen.

Verboten sind als Wertequelle:

- Same-Car-Setup-Fallbacks,
- Cross-Car-Fusion,
- Spenderstrecken,
- Nearest-Track-Logik,
- feste Referenz-Setups,
- importierte `.carsetup`-Zahlen als Berechnungsbasis.

## Vier Varianten / sichtbare Buttons

- Michael Schumacher (Very Fast) → `HOTLAP_ATTACK`
- Walter Röhrl (Fast) → `FAST_CONTROL`
- Dieter Düsel (Normal) → `STABLE_LONGRUN`
- Oma Hertha (Entspannt) → `SAFE`

## Export-Gate

Vor dem Speichern einer `.carsetup` werden Fahrzeugidentität, unterstützte Felder, Plausibilität und ein Decode→Encode/Patch→Decode-Roundtrip geprüft. Ein Fehler blockiert den Export.

## Automatischer Verifikationstest

```text
python3 tools/verify_godfather.py
```

Der Test prüft 6 Fahrzeuge × 36 Layouts × 4 Varianten = 864 Kombinationen inklusive Binär-Patch und Roundtrip.
