package com.greenbuddy.acevosetupengineer;

import java.util.*;

public final class SetupValidator {
    public static final class Result{public boolean ok=true;public final List<String>warnings=new ArrayList<>(),errors=new ArrayList<>();public String text(){StringBuilder b=new StringBuilder(ok?"PASS":"FAIL");for(String x:warnings)b.append(" | WARN: ").append(x);for(String x:errors)b.append(" | ERROR: ").append(x);return b.toString();}}
    private SetupValidator(){}
    private static boolean finite(float x){return Float.isFinite(x);}
    private static void range(Result r,String n,float x,float lo,float hi){if(!finite(x)||x<lo||x>hi){r.ok=false;r.errors.add(n+"="+x+" outside "+lo+".."+hi);}}
    private static void optNonNegative(Result r,String n,float x,float hi){if(Float.isNaN(x))return;if(!finite(x)||x<0||x>hi){r.ok=false;r.errors.add(n+"="+x+" invalid");}}
    public static Result check(LiveSetupSpec s){Result r=new Result();for(int i=0;i<4;i++){range(r,"pressure["+i+"]",s.pressure[i],15,40);range(r,"camber["+i+"]",s.camber[i],-8,3);range(r,"toe["+i+"]",s.toe[i],-2,2);optNonNegative(r,"spring["+i+"]",s.spring[i],2_000_000);if(!Float.isNaN(s.bumpstopRange[i]))range(r,"bumpstopRange["+i+"]",s.bumpstopRange[i],-0.5f,0.5f);optNonNegative(r,"bumpstopRate["+i+"]",s.bumpstopRate[i],1_000_000);optNonNegative(r,"slowBump["+i+"]",s.slowBump[i],1_000_000);optNonNegative(r,"fastBump["+i+"]",s.fastBump[i],1_000_000);optNonNegative(r,"slowRebound["+i+"]",s.slowRebound[i],1_000_000);optNonNegative(r,"fastRebound["+i+"]",s.fastRebound[i],1_000_000);}for(int i=0;i<2;i++)optNonNegative(r,"ARB["+i+"]",s.arb[i],2_000_000);optNonNegative(r,"diffPreload",s.diffPreload,5_000);range(r,"rideHeightF",s.rideHeight[0],20,200);range(r,"rideHeightR",s.rideHeight[1],20,200);range(r,"brakeBias",s.brakeBias,40,80);range(r,"fuel",s.fuel,0,150);if(s.tcPresent)range(r,"TC",s.tc,0,30);if(s.absPresent)range(r,"ABS",s.abs,0,30);
        boolean all27=true;for(float p:s.pressure)if(Math.abs(p-27.0f)>0.001f)all27=false;if(all27)r.warnings.add("all four stored pressures are exactly 27.0 PSI; verify cold/hot meaning before driving");if(Math.abs(s.pressure[0]-s.pressure[1])>3||Math.abs(s.pressure[2]-s.pressure[3])>3)r.warnings.add("large left/right pressure split");if(s.rideHeight[1]+10<s.rideHeight[0])r.warnings.add("rear ride height far below front");return r;}
}
