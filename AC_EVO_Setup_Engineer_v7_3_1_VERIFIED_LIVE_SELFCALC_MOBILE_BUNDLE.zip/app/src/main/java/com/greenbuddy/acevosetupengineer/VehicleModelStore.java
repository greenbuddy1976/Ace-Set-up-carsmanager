package com.greenbuddy.acevosetupengineer;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Loads a synthetic same-car vehicle model built from component-wise medians of
 * multiple genuine same-car .carsetup files. No single source track is selected.
 */
public final class VehicleModelStore {
    public static final class Model {
        public String carId="",sha256="",signature=""; public byte[] bytes; public LiveSetupSpec center;
        public final List<LiveSetupSpec> calibration=new ArrayList<>(); public int sourceCount;
        public float min(java.util.function.Function<LiveSetupSpec,Float> f){float v=Float.POSITIVE_INFINITY;for(LiveSetupSpec s:calibration){Float x=f.apply(s);if(x!=null&&Float.isFinite(x))v=Math.min(v,x);}return v==Float.POSITIVE_INFINITY?0:v;}
        public float max(java.util.function.Function<LiveSetupSpec,Float> f){float v=Float.NEGATIVE_INFINITY;for(LiveSetupSpec s:calibration){Float x=f.apply(s);if(x!=null&&Float.isFinite(x))v=Math.max(v,x);}return v==Float.NEGATIVE_INFINITY?0:v;}
    }
    private final Context context; private final JSONObject cars; private final Map<String,Model> cache=new HashMap<>();
    public VehicleModelStore(Context c)throws Exception{context=c.getApplicationContext();JSONObject root=new JSONObject(readText("vehicle_model_manifest.json"));cars=root.getJSONObject("cars");}
    public synchronized Model load(String carId,String carName,String explicitSignature)throws Exception{
        Model old=cache.get(carId);if(old!=null)return old;JSONObject o=cars.optJSONObject(carId);if(o==null)throw new IOException("No multi-source vehicle model for "+carId);
        Model m=new Model();m.carId=carId;m.sha256=o.getString("sha256");m.signature=o.getString("signature");m.bytes=readBytes(o.getString("asset"));String h=UserContentStore.sha256(m.bytes);if(!m.sha256.equalsIgnoreCase(h))throw new IOException("Vehicle model SHA-256 mismatch for "+carId);if(!LiveCarSetupCodec.signatureMatches(m.bytes,carId,explicitSignature))throw new IOException("Vehicle model car signature mismatch for "+carId);m.center=LiveCarSetupCodec.decode(m.bytes,carId,carName,explicitSignature);
        JSONArray a=o.getJSONArray("sources");for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);byte[] b=readBytes(x.getString("asset"));if(!x.getString("sha256").equalsIgnoreCase(UserContentStore.sha256(b)))throw new IOException("Calibration SHA-256 mismatch: "+x.getString("name"));if(!LiveCarSetupCodec.signatureMatches(b,carId,explicitSignature))throw new IOException("Calibration car mismatch: "+x.getString("name"));m.calibration.add(LiveCarSetupCodec.decode(b,carId,carName,explicitSignature));}m.sourceCount=m.calibration.size();if(m.sourceCount<3)throw new IOException("Vehicle model needs >=3 verified same-car calibration files");cache.put(carId,m);return m;
    }
    public boolean supports(String carId){return cars.has(carId);}
    private byte[] readBytes(String name)throws Exception{try(InputStream in=context.getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toByteArray();}}
    private String readText(String name)throws Exception{return new String(readBytes(name),StandardCharsets.UTF_8);}
}
