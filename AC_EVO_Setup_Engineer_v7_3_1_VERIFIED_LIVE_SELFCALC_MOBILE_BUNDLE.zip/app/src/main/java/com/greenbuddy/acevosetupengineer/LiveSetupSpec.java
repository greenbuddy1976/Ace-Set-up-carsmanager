package com.greenbuddy.acevosetupengineer;

import java.util.Arrays;

/** Values we can conservatively decode and re-write in AC EVO .carsetup files. */
public class LiveSetupSpec {
    public String carId="",carName="",trackToken="",trackLabel="",variant="FAST_CONTROL";
    public String sourceEntry="",sourceVersion="",sourceSha256="",generationMode="",confidence="",validation="",engineeringAudit="",sourceEvidence="",note="";
    public String calculationEvidence="",vehicleModelSha256="";
    public int vehicleModelSources=0,trackFusionSamples=0,trackFusionCars=0;

    public float[] pressure={0,0,0,0},camber={0,0,0,0},toe={0,0,0,0},rideHeight={0,0};
    public float brakeBias,tc,abs,fuel; public Float tc2=null,wing=null;
    public boolean tcPresent=true,absPresent=true,wingVerified=false;

    // Additional high/likely-confidence setup-ripple / genuine-file cross-checked fields.
    // NaN means not present/usable in a particular file; absent fields are never created by the writer.
    public float[] arb={Float.NaN,Float.NaN};
    public float[] spring={Float.NaN,Float.NaN,Float.NaN,Float.NaN};
    public float[] bumpstopRange={Float.NaN,Float.NaN,Float.NaN,Float.NaN};
    public float[] bumpstopRate={Float.NaN,Float.NaN,Float.NaN,Float.NaN};
    public float[] slowBump={Float.NaN,Float.NaN,Float.NaN,Float.NaN};
    public float[] fastBump={Float.NaN,Float.NaN,Float.NaN,Float.NaN};
    public float[] slowRebound={Float.NaN,Float.NaN,Float.NaN,Float.NaN};
    public float[] fastRebound={Float.NaN,Float.NaN,Float.NaN,Float.NaN};
    public float diffPreload=Float.NaN;

    public LiveSetupSpec copy(){
        LiveSetupSpec s=new LiveSetupSpec();
        s.carId=carId;s.carName=carName;s.trackToken=trackToken;s.trackLabel=trackLabel;s.variant=variant;
        s.sourceEntry=sourceEntry;s.sourceVersion=sourceVersion;s.sourceSha256=sourceSha256;s.generationMode=generationMode;s.confidence=confidence;s.validation=validation;s.engineeringAudit=engineeringAudit;s.sourceEvidence=sourceEvidence;s.note=note;
        s.calculationEvidence=calculationEvidence;s.vehicleModelSha256=vehicleModelSha256;s.vehicleModelSources=vehicleModelSources;s.trackFusionSamples=trackFusionSamples;s.trackFusionCars=trackFusionCars;
        s.pressure=pressure.clone();s.camber=camber.clone();s.toe=toe.clone();s.rideHeight=rideHeight.clone();
        s.brakeBias=brakeBias;s.tc=tc;s.abs=abs;s.fuel=fuel;s.tc2=tc2;s.wing=wing;s.tcPresent=tcPresent;s.absPresent=absPresent;s.wingVerified=wingVerified;
        s.arb=arb.clone();s.spring=spring.clone();s.bumpstopRange=bumpstopRange.clone();s.bumpstopRate=bumpstopRate.clone();s.slowBump=slowBump.clone();s.fastBump=fastBump.clone();s.slowRebound=slowRebound.clone();s.fastRebound=fastRebound.clone();s.diffPreload=diffPreload;
        return s;
    }
    @Override public String toString(){return carName+" / "+trackLabel+" / "+variant+" pressures="+Arrays.toString(pressure);}
}
