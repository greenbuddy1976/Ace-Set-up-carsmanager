package com.greenbuddy.acevosetupengineer;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Selected-track repository. No nearest-track or donor-track lookup exists. */
public final class UnifiedRepository {
    private final Context context;private final UserContentStore user;private final LinkedHashMap<String,TrackDNA> tracks=new LinkedHashMap<>();
    public UnifiedRepository(Context c,UserContentStore u)throws Exception{context=c.getApplicationContext();user=u;reload();}
    public void reload()throws Exception{tracks.clear();JSONArray cat=new JSONArray(readText("track_dna.json"));Map<String,TrackDNA> all=new LinkedHashMap<>();for(int i=0;i<cat.length();i++){TrackDNA d=TrackDNA.fromJson(cat.getJSONObject(i));all.put(d.token,d);}JSONArray order=new JSONArray(readText("track_order.json"));for(int i=0;i<order.length();i++){String t=order.getString(i);TrackDNA d=all.get(t);if(d==null)throw new IOException("Track order references unknown token: "+t);tracks.put(t,d);}for(TrackDNA d:user.customTracks())tracks.put(d.token,d);}
    private String readText(String name)throws Exception{try(InputStream in=context.getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toString(StandardCharsets.UTF_8.name());}}
    public List<String> tokens(){return new ArrayList<>(tracks.keySet());}public List<String> labels(){ArrayList<String>x=new ArrayList<>();for(TrackDNA d:tracks.values())x.add(d.track+(d.token.startsWith("user_track_")?" · USER":""));return x;}public String label(String token){TrackDNA d=tracks.get(token);return d==null?token:d.track;}public TrackDNA dna(String token){TrackDNA d=tracks.get(token);if(d==null)throw new IllegalArgumentException("Unknown selected track: "+token);return d;}
}
