import os, struct, hashlib, json, statistics, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'app/src/main/assets'
SRC=ROOT/'calibration_sources'
OUT=ROOT/'vehicle_models'
OUT.mkdir(exist_ok=True)

class F:
    __slots__=('n','w','v','raw','child')
    def __init__(self,n,w,v=None,raw=None,child=None): self.n=n; self.w=w; self.v=v; self.raw=raw; self.child=child
class M:
    def __init__(self): self.fields=[]

def rv(d,p):
    v=0; sh=0
    while p[0]<len(d) and sh<64:
        b=d[p[0]];p[0]+=1;v|=(b&127)<<sh
        if not b&128:return v
        sh+=7
    raise ValueError('bad varint')
def wv(v):
    o=bytearray()
    while v & ~0x7f: o.append((v&0x7f)|0x80);v>>=7
    o.append(v);return bytes(o)
def parse(d):
    m=M(); p=[0]
    while p[0]<len(d):
        key=rv(d,p); n=key>>3; w=key&7
        if n<=0 or w not in (0,1,2,5):raise ValueError('invalid')
        if w==0: f=F(n,w,v=rv(d,p))
        elif w==1: f=F(n,w,raw=d[p[0]:p[0]+8]);p[0]+=8
        elif w==5: f=F(n,w,raw=d[p[0]:p[0]+4]);p[0]+=4
        else:
            ln=rv(d,p); raw=d[p[0]:p[0]+ln];p[0]+=ln; child=None
            try:
                c=parse(raw)
                if c.fields: child=c
            except: pass
            f=F(n,w,raw=raw,child=child)
        m.fields.append(f)
    return m
def enc(m):
    o=bytearray()
    for f in m.fields:
        o+=wv((f.n<<3)|f.w)
        if f.w==0:o+=wv(f.v)
        elif f.w in (1,5):o+=f.raw
        else:
            x=enc(f.child) if f.child is not None else f.raw
            o+=wv(len(x));o+=x
    return bytes(o)

def f32(b):return struct.unpack('<f',b)[0]
def bf(v):return struct.pack('<f',float(v))
def finite_plausible(v):return math.isfinite(v) and abs(v)<1e9

def occ_fields(m):
    # path element n:occurrence across same n/w
    ctr={}
    for f in m.fields:
        key=(f.n,f.w); occ=ctr.get(key,0);ctr[key]=occ+1
        yield f,(f.n,f.w,occ)

def index_fields(m, prefix=()):
    out={}
    for f,el in occ_fields(m):
        p=prefix+(el,)
        if f.w==5 and len(f.raw)==4:
            out[p]=('f32',f)
        elif f.w==2 and f.child is not None:
            out.update(index_fields(f.child,p))
    return out

def raw_len_index(m):
    # only known packed float vectors: root field1 child field1, and root field6 child field1.
    vals={}
    def msg(n,occ=0):
        k=0
        for f in m.fields:
            if f.n==n and f.w==2 and f.child is not None:
                if k==occ:return f.child
                k+=1
        return None
    for topn in (1,6):
        c=msg(topn)
        if not c: continue
        k=0
        for f in c.fields:
            if f.n==1 and f.w==2:
                if len(f.raw)%4==0 and 1<=len(f.raw)//4<=16:
                    vv=[f32(f.raw[i:i+4]) for i in range(0,len(f.raw),4)]
                    if all(finite_plausible(x) for x in vv): vals[(topn,1,k)]=(f,vv)
                k+=1
    return vals

def median(vals):return statistics.median(vals)
manifest={'version':'7.3.1','method':'component-wise median of every matching protobuf fixed32 float plus known packed float vectors across >=3 UNIQUE genuine same-car calibration files; duplicate binaries are SHA-256-deduplicated; no single source track is selected','cars':{}}
for car_dir in sorted(p for p in SRC.iterdir() if p.is_dir()):
    files=sorted(car_dir.glob('*.carsetup'))
    # Never weight the same binary twice merely because it has two filenames.
    uniq=[]; seen_sha=set()
    for fp in files:
        h=hashlib.sha256(fp.read_bytes()).hexdigest()
        if h in seen_sha: continue
        seen_sha.add(h); uniq.append(fp)
    files=uniq
    if len(files)<3: raise SystemExit(f'{car_dir.name}: need >=3 UNIQUE calibration files')
    datas=[p.read_bytes() for p in files]
    msgs=[parse(d) for d in datas]
    sigs=[]
    import re
    for d in datas:
        s=d.decode('latin1','ignore')
        mm=re.search(r'ks_[A-Za-z0-9_]+_preset_[A-Za-z0-9_]+_mech_[0-9]+_preset_[A-Za-z0-9_]+_visual_[0-9]+',s)
        sigs.append(mm.group(0) if mm else '')
    # Keep the dominant explicit vehicle signature; ignore legacy/unsigned calibration files.
    from collections import Counter
    valid=[(p,d,m,s) for p,d,m,s in zip(files,datas,msgs,sigs) if s]
    if not valid: raise SystemExit(f'{car_dir.name}: no signed calibration source')
    dominant=Counter(v[3] for v in valid).most_common(1)[0][0]
    valid=[v for v in valid if v[3]==dominant]
    if len(valid)<3: raise SystemExit(f'{car_dir.name}: need >=3 same-signature calibration files, got {len(valid)}')
    files=[v[0] for v in valid];datas=[v[1] for v in valid];msgs=[v[2] for v in valid];sigs=[v[3] for v in valid]
    base=msgs[0]
    inds=[index_fields(m) for m in msgs]
    common=set(inds[0])
    for x in inds[1:]: common &= set(x)
    patched=0
    for path in common:
        vals=[f32(x[path][1].raw) for x in inds]
        if all(finite_plausible(v) for v in vals):
            inds[0][path][1].raw=bf(median(vals));patched+=1
    raws=[raw_len_index(m) for m in msgs]
    commonr=set(raws[0])
    for x in raws[1:]:commonr &= set(x)
    packed=0
    for p in commonr:
        arrs=[x[p][1] for x in raws]
        if len({len(a) for a in arrs})!=1:continue
        med=[median([a[i] for a in arrs]) for i in range(len(arrs[0]))]
        raws[0][p][0].raw=b''.join(bf(v) for v in med); raws[0][p][0].child=None;packed+=len(med)
    out=enc(base)
    # signature must survive
    if sigs[0].encode('latin1') not in out: raise SystemExit(f'{car_dir.name}: signature lost')
    outp=OUT/(car_dir.name+'.carsetup');outp.write_bytes(out)
    manifest['cars'][car_dir.name]={
        'asset':'vehicle_models/'+outp.name,
        'sha256':hashlib.sha256(out).hexdigest(),
        'signature':sigs[0],
        'source_count':len(files),
        'fixed32_fields_medianized':patched,
        'packed_float_values_medianized':packed,
        'sources':[{'name':p.name,'asset':'calibration_sources/'+car_dir.name+'/'+p.name,'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d)} for p,d in zip(files,datas)]
    }
    print(car_dir.name, 'sources',len(files),'out',len(out),'fields',patched,'packed',packed,manifest['cars'][car_dir.name]['sha256'])
(ROOT/'vehicle_model_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
