# AC EVO Setup Engineer v7.3.1 — VERIFIED LIVE + SELF-CALC

## Source order
1. Every generation starts with a fresh LIVE search on RacePlace and SetupsMarket.
2. LIVE EXACT is accepted only when both the selected car and the selected layout match and the downloaded `.carsetup` passes the binary same-car signature + decoder checks.
3. SetupsMarket layout authority is its structured detail metadata (`Car · Track · ...`), never a free-text setup title.
4. If no exact binary is accepted, there is no donor/nearest/reference setup selection.
5. SELF-CALC starts from a synthetic same-car vehicle model built by component-wise medians of >=3 UNIQUE genuine same-car calibration binaries (SHA-256 + car-signature checked).
6. Optional target-layout influence is an aggregate signal: target-layout setups from >=2 distinct supported cars are normalized against each car's own multi-source range, median-combined per car, then median-combined across cars. No foreign binary or absolute foreign setup value is copied.
7. Pressure, fuel and electronics are never cross-car fused. If a field has insufficient target-layout evidence, the same-car median model value is retained.
8. If complete LIVE coverage cannot be proven, calculation may still be produced but is explicitly marked `LIVE-COVERAGE-WARN`; the app must not claim that no exact setup exists.

## Guardrails
- No Track-DNA numeric fallback.
- No nearest-track candidate fallback.
- No single donor/reference file or track.
- No invented 27 PSI target.
- Variant/fine-tuning edits use only observed same-car quantiles and are range-gated by the engineering self-audit.
- `ALLE 4` means four variants for the selected track: SAFE, STABLE_LONGRUN, FAST_CONTROL, HOTLAP_ATTACK.

## Verification
Run `python3 tools/verify_v7_3_1.py`. The GitHub release workflow runs the same verification before signing the APK.

## Important scope note
The AC EVO `.carsetup` field mapping is community reverse-engineered from genuine files; it is not an official KUNOS public schema. Unknown/unverified fields are not automatically invented. The project therefore labels calculated results as SELF-CALC / DATA-FUSED / MODEL-ONLY rather than as an official factory setup.
