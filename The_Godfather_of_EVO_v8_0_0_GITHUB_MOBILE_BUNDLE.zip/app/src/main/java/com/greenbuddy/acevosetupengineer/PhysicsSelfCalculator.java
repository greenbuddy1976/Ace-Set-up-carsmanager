package com.greenbuddy.acevosetupengineer;

/**
 * Deterministic donor-free calculator.
 * Runtime inputs are ONLY: selected vehicle engineering/parameter-scale profile,
 * selected track engineering profile, requested variant, and structure-field presence.
 * No .carsetup numeric value is decoded into this calculator.
 */
public final class PhysicsSelfCalculator {
    private PhysicsSelfCalculator(){}
    private static final class S {
        float pF,pR,cF,cR,tF,tR,rhF,rhR,spF,spR,arbF,arbR,bsF,bsR,brF,brR,sbF,sbR,fbF,fbR,srF,srR,frF,frR,diff,bb,tc,tc2,abs,wing;
        S(float...x){int i=0;pF=x[i++];pR=x[i++];cF=x[i++];cR=x[i++];tF=x[i++];tR=x[i++];rhF=x[i++];rhR=x[i++];spF=x[i++];spR=x[i++];arbF=x[i++];arbR=x[i++];bsF=x[i++];bsR=x[i++];brF=x[i++];brR=x[i++];sbF=x[i++];sbR=x[i++];fbF=x[i++];fbR=x[i++];srF=x[i++];srR=x[i++];frF=x[i++];frR=x[i++];diff=x[i++];bb=x[i++];tc=x[i++];tc2=x[i++];abs=x[i++];wing=x[i++];}
    }
    private static S scale(String id){
        if("audi_r8_lms_gt3_evo_ii".equals(id))return new S(26,25.5f,-3.5f,-2.7f,-.02f,.03f,56,75,220000,280000,34000,55000,-.030f,-.011f,1700,1700,7,6.5f,8000,7000,6.5f,7.5f,6000,4000,90,60.5f,5.5f,1.5f,4,5);
        if("porsche_992_gt3_r_rennsport".equals(id))return new S(25.5f,25,-3.5f,-2.7f,.02f,.02f,54,66,275000,305000,9300,35000,-.010f,.018f,1500,1000,6,6.5f,1000,1000,5.5f,8.5f,1000,1000,85,58.5f,5.5f,2.5f,4,11);
        if("ferrari_296_gt3".equals(id))return new S(26,25.5f,-3.4f,-2.6f,.02f,0,54,60,305000,225000,59000,44000,-.036f,-.070f,2000,1700,27,25,8000,7000,30.5f,30,6000,4000,80,60.2f,6,2.5f,4,9);
        if("dallara_exp".equals(id))return new S(23.1f,22.2f,-3.0f,-2.1f,-.05f,.21f,52,65,100000,150000,115000,116000,-.01135f,.0131f,1000,1000,8100,6800,9500,8800,2800,11200,3800,11800,40,59.3f,1,Float.NaN,2.5f,6);
        if("bmw_m4_gt3_evo".equals(id))return new S(25.5f,25,-3.4f,-2.6f,0,.10f,55,64,175000,145000,58000,25000,.030f,.040f,1800,1200,30,26,7000,7000,35,38,7000,7000,70,61,5.5f,Float.NaN,3,5);
        return new S(25,24.8f,-3.7f,-2.9f,-.08f,.07f,60,70,165000,130000,43000,25000,.006f,.019f,2800,2000,3,3,4000,3500,3.5f,3.5f,12000,12000,150,61,4.5f,3,4.5f,6);
    }
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private static float r(float v,int d){float p=(float)Math.pow(10,d);return Math.round(v*p)/p;}
    private static float n(int x){return clamp((x-5.5f)/4.5f,-1f,1f);}
    private static int vr(String v){if("SAFE".equals(v))return 0;if("STABLE_LONGRUN".equals(v))return 1;if("FAST_CONTROL".equals(v))return 2;return 3;}
    private static float variant(int rank,float safe,float stable,float fast,float hot){return rank==0?safe:rank==1?stable:rank==2?fast:hot;}

    public static LiveSetupSpec calculate(VehicleEngineeringProfile p,TrackDNA t,String variant,LiveCarSetupCodec.StructureInfo st){
        if(p==null||t==null||st==null)throw new IllegalArgumentException("Missing engineering input");S q=scale(p.carId);int v=vr(variant);float rough=n(t.roughness),high=n(t.highSpeed),drag=n(t.drag),brake=n(t.braking),tract=n(t.traction),kerb=n(t.kerb),rot=n(t.rotation);
        LiveSetupSpec s=new LiveSetupSpec();s.carId=p.carId;s.carName=p.carName;s.trackToken=t.token;s.trackLabel=t.track;s.variant=variant;s.generationMode="SELF CALCULATED";s.confidence="VEHICLE-SPECIFIC ENGINEERING MODEL";

        float pAdj=.18f*high-.12f*rough;for(int i=0;i<2;i++)s.pressure[i]=r(clamp(q.pF+pAdj,20,30),1);for(int i=2;i<4;i++)s.pressure[i]=r(clamp(q.pR+pAdj,20,30),1);
        float attack=variant(v,.12f,.06f,0,-.08f);float cf=q.cF-.22f*high-.12f*rot+.10f*rough-attack,cr=q.cR-.16f*high-.06f*rot+.10f*rough-attack*.7f;for(int i=0;i<2;i++)s.camber[i]=r(clamp(cf,-5.5f,-1.5f),2);for(int i=2;i<4;i++)s.camber[i]=r(clamp(cr,-4.5f,-1),2);
        float tf=q.tF-.020f*rot+variant(v,.010f,.006f,0,-.010f),tr=q.tR+.018f*tract+.010f*high+variant(v,.018f,.010f,0,-.008f);for(int i=0;i<2;i++)s.toe[i]=r(clamp(tf,-.30f,.25f),3);for(int i=2;i<4;i++)s.toe[i]=r(clamp(tr,-.10f,.35f),3);

        s.rideHeight[0]=r(clamp(q.rhF+2.6f*rough+1.8f*kerb-1.3f*high+variant(v,2,1,0,-.5f),35,100),1);s.rideHeight[1]=r(clamp(q.rhR+2.3f*rough+1.6f*kerb+1.0f*high+variant(v,2,1,0,-.5f),45,120),1);
        float stiff=1+.045f*high-.075f*rough-.035f*kerb+variant(v,-.045f,-.02f,0,.035f);for(int i=0;i<2;i++)if(st.spring[i])s.spring[i]=r(clamp(q.spF*stiff,50000,400000),0);for(int i=2;i<4;i++)if(st.spring[i])s.spring[i]=r(clamp(q.spR*stiff*(1+.025f*tract),50000,400000),0);
        if(st.arb){s.arb[0]=r(clamp(q.arbF*(1+.07f*high+.05f*rot-.09f*rough+variant(v,-.04f,-.02f,0,.035f)),5000,150000),0);s.arb[1]=r(clamp(q.arbR*(1+.06f*rot+.04f*tract-.08f*rough+variant(v,-.05f,-.025f,0,.045f)),5000,150000),0);}

        for(int i=0;i<4;i++){boolean front=i<2;float br=front?q.bsF:q.bsR;float rate=front?q.brF:q.brR;float sb=front?q.sbF:q.sbR,fb=front?q.fbF:q.fbR,sr=front?q.srF:q.srR,fr=front?q.frF:q.frR;
            if(st.bumpstopRange[i])s.bumpstopRange[i]=r(clamp(br+(br<0?-1:1)*(.0020f*rough+.0010f*kerb+variant(v,.0015f,.0008f,0,-.0005f)),-.12f,.12f),5);
            if(st.bumpstopRate[i])s.bumpstopRate[i]=r(clamp(rate*(1+.07f*high-.10f*rough+variant(v,-.05f,-.02f,0,.035f)),300,10000),0);
            float slowFactor=1+.04f*high-.06f*rough+variant(v,-.04f,-.02f,0,.03f),fastFactor=1-.08f*rough-.05f*kerb+variant(v,-.05f,-.025f,0,.02f),rebFactor=1+.04f*high-.05f*rough+variant(v,-.035f,-.015f,0,.035f);
            if(st.slowBump[i])s.slowBump[i]=r(clamp(sb*slowFactor,1,30000),sb<100?1:0);if(st.fastBump[i])s.fastBump[i]=r(clamp(fb*fastFactor,100,30000),0);if(st.slowRebound[i])s.slowRebound[i]=r(clamp(sr*rebFactor,1,35000),sr<100?1:0);if(st.fastRebound[i])s.fastRebound[i]=r(clamp(fr*rebFactor,100,35000),0);
        }

        if(st.diffPreload)s.diffPreload=r(clamp(q.diff*(1+.12f*tract-.07f*rot+variant(v,.08f,.04f,0,-.05f)),20,300),0);
        s.brakeBias=r(clamp(q.bb+.45f*brake+.25f*(p.brakingStability-.5f)+variant(v,.35f,.18f,0,-.18f),50,63),1);
        s.tcPresent=st.tc;s.absPresent=st.abs;if(st.tc)s.tc=r(clamp(q.tc+.8f*tract+variant(v,2,1,0,-1),0,12),0);if(st.tc2&&Float.isFinite(q.tc2))s.tc2=r(clamp(q.tc2+.35f*tract+variant(v,1,.5f,0,-.5f),0,12),0);if(st.abs)s.abs=r(clamp(q.abs+.7f*brake+variant(v,1,.5f,0,-.5f),0,12),0);
        s.fuel="SAFE".equals(variant)?65:"STABLE_LONGRUN".equals(variant)?52:"FAST_CONTROL".equals(variant)?32:18;
        s.wingVerified=st.wing;if(st.wing){s.wing=r(clamp(q.wing+1.6f*high+1.1f*rot-1.5f*drag+variant(v,1,.5f,0,-1),1,15),0);}
        s.sourceEntry="structure_templates/"+p.carId+".carsetup";s.sourceVersion="8.0.0 vehicle-specific donor-free model";s.calculationEvidence="Selected vehicle engineering/parameter-scale profile + selected track engineering profile + variant. No donor setup, no donor track, no same-car setup values, no cross-car setup values are runtime calculation inputs.";
        return s;
    }
}
