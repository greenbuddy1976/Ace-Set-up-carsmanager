package com.greenbuddy.acevosetupengineer;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Loads binary structure carriers only; stored setup numbers are never decoded as self-calc inputs. */
public final class StructureTemplateStore {
    public static final class Template{public String carId="",asset="",sha256="",signature="";public byte[] bytes;public LiveCarSetupCodec.StructureInfo structure;}
    private final Context context;private final JSONObject cars;private final Map<String,Template> cache=new HashMap<>();
    public StructureTemplateStore(Context c)throws Exception{context=c.getApplicationContext();cars=new JSONObject(readText("structure_manifest.json")).getJSONObject("cars");}
    public boolean supports(String carId){return cars.has(carId);}
    public synchronized Template load(String carId,String explicitSignature)throws Exception{Template old=cache.get(carId);if(old!=null)return old;JSONObject o=cars.optJSONObject(carId);if(o==null)throw new IOException("No structure template for "+carId);Template t=new Template();t.carId=carId;t.asset=o.getString("asset");t.sha256=o.getString("sha256");t.signature=o.getString("signature");t.bytes=readBytes(t.asset);if(!t.sha256.equalsIgnoreCase(UserContentStore.sha256(t.bytes)))throw new IOException("Structure SHA-256 mismatch for "+carId);if(!LiveCarSetupCodec.signatureMatches(t.bytes,carId,explicitSignature))throw new IOException("Structure template belongs to wrong car: "+carId);t.structure=LiveCarSetupCodec.inspectStructure(t.bytes,carId,explicitSignature);cache.put(carId,t);return t;}
    private byte[] readBytes(String name)throws Exception{try(InputStream in=context.getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toByteArray();}}
    private String readText(String n)throws Exception{return new String(readBytes(n),StandardCharsets.UTF_8);}
}
