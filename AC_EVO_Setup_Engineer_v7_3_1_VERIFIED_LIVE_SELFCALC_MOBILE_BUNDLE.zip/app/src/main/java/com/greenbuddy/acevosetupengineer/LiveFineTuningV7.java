package com.greenbuddy.acevosetupengineer;

import java.util.*;

/**
 * Optional conservative fine tuning. No fixed magic setup deltas are used.
 * Every automatic target is an observed same-car quantile; intensity only interpolates
 * from the already calculated setup toward that verified same-car value.
 * Pressure is never auto-edited.
 */
public final class LiveFineTuningV7 {
    public static final String NONE="Kein Fine-Tuning";
    public static final String[] PROBLEMS={NONE,"Heck beim Bremsen instabil","Untersteuern beim Einlenken","Heck am Kurvenausgang nervös","Springt über Kerbs / Kuppen","Auto ist zu träge","Reifenverschleiß zu hoch","Highspeed-Heck nervös","Mehr Topspeed"};
    public static class Result{public LiveSetupSpec spec;public String summary="";}
    private interface Get{float v(LiveSetupSpec s);}private interface Set{void v(LiveSetupSpec s,float x);}
    private LiveFineTuningV7(){}
    private static int p(int x){return Math.max(1,Math.min(3,x));}
    private static boolean ok(float x){return Float.isFinite(x);}
    private static float quantile(VehicleModelStore.Model m,Get g,float q){ArrayList<Float>x=new ArrayList<>();for(LiveSetupSpec s:m.calibration){float v=g.v(s);if(ok(v))x.add(v);}if(x.isEmpty())return Float.NaN;Collections.sort(x);if(x.size()==1)return x.get(0);float pos=q*(x.size()-1);int a=(int)Math.floor(pos),b=(int)Math.ceil(pos);return a==b?x.get(a):x.get(a)+(x.get(b)-x.get(a))*(pos-a);}
    private static float blend(float from,float to,int intensity){if(!ok(from)||!ok(to))return from;float t=p(intensity)/3f;return from+(to-from)*t;}
    private static void toward(LiveSetupSpec s,VehicleModelStore.Model m,Get g,Set set,float q,int intensity,String label,List<String> notes){float old=g.v(s),target=quantile(m,g,q);if(!ok(old)||!ok(target))return;float v=blend(old,target,intensity);set.v(s,v);if(Math.abs(v-old)>0.00001f)notes.add("• "+label+": Richtung Same-Car Q"+Math.round(q*100)+" ("+fmt(old)+" → "+fmt(v)+")");}
    private static String fmt(float v){return String.format(Locale.US,"%.4f",v).replaceAll("0+$","").replaceAll("\\.$","");}

    public static String detect(String text,String fallback){
        if(text==null||text.trim().isEmpty())return fallback;String t=text.toLowerCase(Locale.ROOT);
        if((t.contains("brems")||t.contains("anbrems"))&&(t.contains("heck")||t.contains("dreht")||t.contains("instabil")))return PROBLEMS[1];
        if(t.contains("unterste")||(t.contains("einlenk")&&t.contains("träge")))return PROBLEMS[2];
        if((t.contains("ausgang")||t.contains("gas"))&&(t.contains("heck")||t.contains("traktion")||t.contains("nerv")))return PROBLEMS[3];
        if(t.contains("kerb")||t.contains("kuppe")||t.contains("spring")||t.contains("bodenwelle"))return PROBLEMS[4];
        if(t.contains("träge")||t.contains("reagiert langsam"))return PROBLEMS[5];
        if(t.contains("verschlei")||(t.contains("reifen")&&t.contains("heiß")))return PROBLEMS[6];
        if((t.contains("highspeed")||t.contains("schnell"))&&t.contains("heck"))return PROBLEMS[7];
        if(t.contains("topspeed")||t.contains("endgeschwindigkeit"))return PROBLEMS[8];return fallback;
    }

    public static Result apply(LiveSetupSpec base,String problem,int intensity,VehicleModelStore.Model model){
        Result r=new Result();r.spec=base.copy();if(NONE.equals(problem))return r;List<String> c=new ArrayList<>();
        if(model==null){r.summary="• Fine-Tuning blockiert: kein geprüftes Multi-Source-Same-Car-Modell; keine Magic-Deltas erfunden.\n• Reifendruck unverändert.";return r;}
        int i=p(intensity);
        if(PROBLEMS[1].equals(problem)){
            toward(r.spec,model,s->s.brakeBias,(s,v)->s.brakeBias=v,.75f,i,"Brake Bias",c);
            for(int k=2;k<4;k++){final int x=k;toward(r.spec,model,s->s.toe[x],(s,v)->s.toe[x]=v,.75f,i,"Rear Toe "+(k==2?"L":"R"),c);}
        }else if(PROBLEMS[2].equals(problem)){
            for(int k=0;k<2;k++){final int x=k;toward(r.spec,model,s->s.toe[x],(s,v)->s.toe[x]=v,.25f,i,"Front Toe "+(k==0?"L":"R"),c);}toward(r.spec,model,s->s.arb[0],(s,v)->s.arb[0]=v,.25f,i,"Front ARB",c);
        }else if(PROBLEMS[3].equals(problem)){
            for(int k=2;k<4;k++){final int x=k;toward(r.spec,model,s->s.toe[x],(s,v)->s.toe[x]=v,.75f,i,"Rear Toe "+(k==2?"L":"R"),c);toward(r.spec,model,s->s.spring[x],(s,v)->s.spring[x]=v,.25f,i,"Rear Spring "+(k==2?"L":"R"),c);}toward(r.spec,model,s->s.arb[1],(s,v)->s.arb[1]=v,.25f,i,"Rear ARB",c);if(r.spec.tcPresent)toward(r.spec,model,s->s.tc,(s,v)->s.tc=v,.75f,i,"TC",c);
        }else if(PROBLEMS[4].equals(problem)){
            for(int k=0;k<2;k++){final int x=k;toward(r.spec,model,s->s.rideHeight[x],(s,v)->s.rideHeight[x]=v,.75f,i,(k==0?"Front":"Rear")+" Ride Height",c);}for(int k=0;k<4;k++){final int x=k;toward(r.spec,model,s->s.bumpstopRange[x],(s,v)->s.bumpstopRange[x]=v,.75f,i,"Bumpstop Range "+k,c);}
        }else if(PROBLEMS[5].equals(problem)){
            for(int k=0;k<2;k++){final int x=k;toward(r.spec,model,s->s.toe[x],(s,v)->s.toe[x]=v,.25f,i,"Front Toe "+(k==0?"L":"R"),c);}toward(r.spec,model,s->s.arb[0],(s,v)->s.arb[0]=v,.75f,i,"Front ARB",c);
        }else if(PROBLEMS[6].equals(problem)){
            c.add("• Reifenverschleiß: keine automatische Geometrieänderung ohne gemessene Temperatur-/Verschleißdaten. Setup bleibt unverändert.");
        }else if(PROBLEMS[7].equals(problem)){
            for(int k=2;k<4;k++){final int x=k;toward(r.spec,model,s->s.toe[x],(s,v)->s.toe[x]=v,.75f,i,"Rear Toe "+(k==2?"L":"R"),c);}if(r.spec.wingVerified&&r.spec.wing!=null)toward(r.spec,model,s->s.wing==null?Float.NaN:s.wing,(s,v)->s.wing=v,.75f,i,"Rear Wing",c);
        }else if(PROBLEMS[8].equals(problem)){
            if(r.spec.wingVerified&&r.spec.wing!=null)toward(r.spec,model,s->s.wing==null?Float.NaN:s.wing,(s,v)->s.wing=v,.25f,i,"Rear Wing",c);else c.add("• Topspeed: kein automatisch verändertes Aero-Feld, weil für dieses Fahrzeug kein sicher freigegebenes Wing-Feld vorliegt.");
        }
        c.add("• Reifendruck unverändert: Hot-Pressure muss gemessen werden.");c.add("• Keine festen Setup-Deltas: alle geänderten Werte liegen auf beobachteten Same-Car-Quantilpfaden.");
        r.spec.note=base.note+" Fine-Tuning v7.3.1 uses same-car observed quantiles only.";StringBuilder b=new StringBuilder();for(String x:c)b.append(x).append('\n');r.summary=b.toString().trim();return r;
    }
}
