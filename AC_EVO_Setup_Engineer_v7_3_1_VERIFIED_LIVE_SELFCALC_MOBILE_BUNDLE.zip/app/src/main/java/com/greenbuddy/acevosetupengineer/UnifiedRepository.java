package com.greenbuddy.acevosetupengineer;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Track catalog only. Track-DNA values are not loaded or used for setup calculation. */
public final class UnifiedRepository {
    private final Context context;private final UserContentStore user;private final LinkedHashMap<String,String> labels=new LinkedHashMap<>();
    public UnifiedRepository(Context c,UserContentStore u)throws Exception{context=c.getApplicationContext();user=u;reload();}
    public void reload()throws Exception{labels.clear();JSONArray cat=new JSONArray(readText("track_catalog.json"));Map<String,String> all=new LinkedHashMap<>();for(int i=0;i<cat.length();i++){JSONObject o=cat.getJSONObject(i);all.put(o.getString("token"),o.getString("track"));}JSONArray order=new JSONArray(readText("track_order.json"));for(int i=0;i<order.length();i++){String t=order.getString(i);if(!all.containsKey(t))throw new IOException("Track order references unknown token: "+t);labels.put(t,all.get(t));}for(TrackDNA d:user.customTracks())labels.put(d.token,d.track+" · USER");}
    private String readText(String name)throws Exception{try(InputStream in=context.getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toString(StandardCharsets.UTF_8.name());}}
    public List<String> tokens(){return new ArrayList<>(labels.keySet());}public List<String> labels(){return new ArrayList<>(labels.values());}public String label(String token){String x=labels.get(token);if(x==null)return token;return x.endsWith(" · USER")?x.substring(0,x.length()-7):x;}
}
