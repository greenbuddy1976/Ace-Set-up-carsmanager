package com.greenbuddy.acevosetupengineer;

import java.util.*;

public final class CarCatalog {
    public static final class CarItem {
        public final String id,name,signature; public final boolean builtin;
        public CarItem(String i,String n,String s,boolean b){id=i;name=n;signature=s==null?"":s;builtin=b;}
        @Override public String toString(){return name+(builtin?"":" · USER");}
    }
    private CarCatalog(){}
    public static List<CarItem> builtins(){
        List<CarItem> x=new ArrayList<>();
        x.add(new CarItem("ford_mustang_gt3","Ford Mustang GT3","ks_ford_mustang_gt3_preset_msggt3_mech_1_preset_msggt3_visual_1",true));
        x.add(new CarItem("dallara_exp","Dallara EXP","ks_dallara_exp_preset_dalexp_mech_1_preset_dalexp_visual_1",true));
        x.add(new CarItem("audi_r8_lms_gt3_evo_ii","Audi R8 LMS GT3 Evo II","ks_audi_r8_lms_gt3_evo_2_preset_r8gt3_mech_1_preset_r8gt3_visual_1",true));
        x.add(new CarItem("bmw_m4_gt3_evo","BMW M4 GT3 Evo","ks_bmw_m4_gt3_preset_m4gt3_mech_1_preset_m4gt3_visual_1",true));
        x.add(new CarItem("ferrari_296_gt3","Ferrari 296 GT3","ks_ferrari_296_gt3_preset_296gt3_mech_1_preset_296gt3_visual_1",true));
        x.add(new CarItem("porsche_992_gt3_r_rennsport","Porsche 992 GT3 R Rennsport","ks_porsche_992_gt3_r_rennsport_preset_992ren_mech_1_preset_992ren_visual_1",true));
        return x;
    }
    public static CarItem builtin(String id){for(CarItem c:builtins())if(c.id.equals(id))return c;return null;}
}
