package com.greenbuddy.acevosetupengineer;

import java.util.*;

/**
 * Vehicle technical model. It contains only dimensionless engineering characteristics.
 * It contains no setup-file values, no donor-track values and no imported .carsetup baselines.
 */
public final class EngineeringProfileStore {
    private static final Map<String,VehicleEngineeringProfile> M=new LinkedHashMap<>();
    static {
        // frontBalance is a modelling coefficient, not claimed as homologation weight distribution.
        M.put("ford_mustang_gt3",new VehicleEngineeringProfile("ford_mustang_gt3","Ford Mustang GT3","GT3",.56f,.56f,.72f,.70f,.46f,.76f));
        M.put("dallara_exp",new VehicleEngineeringProfile("dallara_exp","Dallara EXP","PROTOTYPE",.46f,.82f,.96f,.72f,.82f,.84f));
        M.put("audi_r8_lms_gt3_evo_ii",new VehicleEngineeringProfile("audi_r8_lms_gt3_evo_ii","Audi R8 LMS GT3 Evo II","GT3",.50f,.62f,.78f,.72f,.72f,.76f));
        M.put("bmw_m4_gt3_evo",new VehicleEngineeringProfile("bmw_m4_gt3_evo","BMW M4 GT3 Evo","GT3",.54f,.60f,.76f,.72f,.58f,.78f));
        M.put("ferrari_296_gt3",new VehicleEngineeringProfile("ferrari_296_gt3","Ferrari 296 GT3","GT3",.49f,.64f,.80f,.74f,.76f,.76f));
        M.put("porsche_992_gt3_r_rennsport",new VehicleEngineeringProfile("porsche_992_gt3_r_rennsport","Porsche 992 GT3 R Rennsport","GT3",.47f,.66f,.84f,.82f,.66f,.72f));
    }
    private EngineeringProfileStore(){}
    public static boolean supports(String carId){return M.containsKey(carId);}
    public static VehicleEngineeringProfile get(String carId){VehicleEngineeringProfile p=M.get(carId);if(p==null)throw new IllegalArgumentException("No verified structure/engineering profile for "+carId);return p;}
    public static Collection<VehicleEngineeringProfile> all(){return Collections.unmodifiableCollection(M.values());}
}
