#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,re,subprocess,tempfile,shutil,sys,textwrap
ROOT=Path(__file__).resolve().parents[1]
JAVA=ROOT/'app/src/main/java/com/greenbuddy/acevosetupengineer'
ASSETS=ROOT/'app/src/main/assets'
errors=[]; notes=[]
def req(cond,msg):
    if not cond: errors.append(msg)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def text(p): return p.read_text(encoding='utf-8')

# Structural/project guardrails
req((ROOT/'settings.gradle').is_file(),'settings.gradle missing')
req((ROOT/'app/build.gradle').is_file(),'app/build.gradle missing')
req('applicationId "com.greenbuddy.acevosetupengineer"' in text(ROOT/'app/build.gradle'),'package id changed')
req('versionName "8.0.0-godfather-final"' in text(ROOT/'app/build.gradle'),'final versionName missing')
req('android:label="The Godfather of EVO"' in text(ROOT/'app/src/main/AndroidManifest.xml'),'app label missing')
req('THE GODFATHER OF EVO' in text(JAVA/'MainActivity.java'),'visible app title missing')
req('© Greenbuddy1976' in text(JAVA/'MainActivity.java'),'copyright missing')
for needle in ['Michael Schumacher','(Very Fast)','Walter Röhrl','(Fast)','Dieter Düsel','(Normal)','Oma Hertha','(Entspannt)']:
    req(needle in text(JAVA/'MainActivity.java'),'button/UI label missing: '+needle)

all_java='\n'.join(text(p) for p in JAVA.glob('*.java'))
for banned in ['VehicleModelStore','LiveTrackFusion','EngineeringSelfAuditV73']:
    req(banned not in all_java,'old runtime logic remains: '+banned)
req(not (ASSETS/'calibration_sources').exists(),'calibration_sources directory must not ship')
req(not (ASSETS/'vehicle_models').exists(),'vehicle_models directory must not ship')
req(not (ASSETS/'fixed_fallback').exists(),'fixed_fallback directory must not ship')
setups=list(ROOT.rglob('*.carsetup'))
req(len(setups)==6,'exactly six structure-carrier .carsetup files must ship, got '+str(len(setups)))
req(all('structure_templates' in p.parts for p in setups),'a .carsetup exists outside structure_templates')
req(not list(ROOT.rglob('*.jks')) and not list(ROOT.rglob('*.keystore')),'private signing key must not ship')

sm=text(JAVA/'LiveSetupSourceManager.java')
req('MAX_LIVE_ATTEMPTS=3' in sm,'3-attempt LIVE constant missing')
req('for(int attempt=1;attempt<=MAX_LIVE_ATTEMPTS;attempt++)' in sm,'three complete LIVE rounds loop missing')
req('scanRacePlace' in sm and 'scanSetupsMarket' in sm,'both LIVE providers missing')
req('LIVE-SUCHE FEHLGESCHLAGEN NACH 3 VERSUCHEN' in sm,'three-failure status missing')
req('saveExactCache' in sm and 'loadExactCache' in sm,'verified exact cache path missing')
req('SELF-CALC · VEHICLE ENGINEERING + SELECTED TRACK' in sm,'independent selfcalc source missing')
req('BINARY STRUCTURE ONLY' in sm,'structure-only gate text missing')
req('r.calculated=true' in sm,'selfcalc result path missing')

# Manifest/data checks
tracks=json.loads(text(ASSETS/'track_dna.json')); order=json.loads(text(ASSETS/'track_order.json')); manifest=json.loads(text(ASSETS/'structure_manifest.json'))
req(len(tracks)==36,'track_dna must contain 36 layouts')
req(len(order)==36 and len(set(order))==36,'track_order must contain 36 unique layouts')
req({x['token'] for x in tracks}==set(order),'track_dna and track_order differ')
for t in tracks:
    for k in ['roughness','highSpeed','drag','braking','traction','kerb','rotation']:
        req(isinstance(t[k],int) and 1<=t[k]<=10,f"track scale invalid {t['token']} {k}")
cars=manifest.get('cars',{})
req(len(cars)==6,'structure manifest must contain 6 cars')
for cid,o in cars.items():
    p=ASSETS/o['asset'];req(p.is_file(),'missing structure carrier '+str(p));
    if p.is_file(): req(sha(p).lower()==o['sha256'].lower(),'structure sha mismatch '+cid)
    req(o['signature'].encode('ascii') in p.read_bytes(),'structure signature missing '+cid)

# Mapped field writer must overwrite every field it intentionally exposes.
codec=text(JAVA/'LiveCarSetupCodec.java')
for needle in ['setFloat(1,s.pressure[i])','setFloat(2,s.camber[i])','setFloat(3,s.toe[i])','setFloat(2,s.rideHeight[0])','setFloat(3,s.rideHeight[1])','setFloat(1,s.fuel)','verifyRoundTrip']:
    req(needle in codec,'codec mapped-field/roundtrip guard missing: '+needle)
req('i.tc2=elec.hasFloat(2)' in codec and 'if(s.tc2!=null)elec.setFloatOnlyIfPresent(2,s.tc2)' in codec,'TC2 structure/write handling missing')
req('i.wing=aero.hasFloat(5)' in codec and 'if(s.wingVerified&&s.wing!=null)aero.setFloatOnlyIfPresent(5,s.wing)' in codec,'wing structure/write handling missing')

# Actual Java runtime verification: compile real calculator+codec and run 6*36*4 patch/decode roundtrips.
if not errors:
    with tempfile.TemporaryDirectory(prefix='godfather_verify_') as td:
        td=Path(td); pkg=td/'com/greenbuddy/acevosetupengineer';pkg.mkdir(parents=True)
        # Minimal TrackDNA replacement avoids Android/org.json dependencies while compiling the real calculator.
        (pkg/'TrackDNA.java').write_text('''package com.greenbuddy.acevosetupengineer; public class TrackDNA { public String token="",track=""; public int roughness,highSpeed,drag,braking,traction,kerb,rotation; }''',encoding='utf-8')
        track_lines=[]
        for t in tracks:
            vals=[t[k] for k in ['roughness','highSpeed','drag','braking','traction','kerb','rotation']]
            name=t['track'].replace('\\','\\\\').replace('"','\\"')
            tok=t['token'].replace('"','')
            track_lines.append('t=new TrackDNA();t.token="%s";t.track="%s";t.roughness=%d;t.highSpeed=%d;t.drag=%d;t.braking=%d;t.traction=%d;t.kerb=%d;t.rotation=%d;tracks.add(t);'%(tok,name,*vals))
        car_lines=[]
        for cid,o in cars.items():
            sig=o['signature'].replace('"','\\"'); asset=str((ASSETS/o['asset']).resolve()).replace('\\','\\\\').replace('"','\\"')
            car_lines.append('runCar("%s","%s","%s",tracks);'%(cid,sig,asset))
        verifier=f'''package com.greenbuddy.acevosetupengineer;
import java.nio.file.*; import java.util.*;
public final class LogicVerifier {{
  static int count=0; static final String[] V={{"SAFE","STABLE_LONGRUN","FAST_CONTROL","HOTLAP_ATTACK"}};
  static String fp(LiveSetupSpec s){{return s.brakeBias+"/"+s.fuel+"/"+Arrays.toString(s.toe)+"/"+Arrays.toString(s.rideHeight)+"/"+Arrays.toString(s.spring)+"/"+Arrays.toString(s.slowBump);}}
  static void runCar(String id,String sig,String file,List<TrackDNA> tracks)throws Exception{{byte[] carrier=Files.readAllBytes(Paths.get(file));LiveCarSetupCodec.StructureInfo st=LiveCarSetupCodec.inspectStructure(carrier,id,sig);VehicleEngineeringProfile p=EngineeringProfileStore.get(id);for(TrackDNA t:tracks){{Set<String> f=new HashSet<>();for(String v:V){{LiveSetupSpec s=PhysicsSelfCalculator.calculate(p,t,v,st);SetupValidator.Result vr=SetupValidator.check(s);if(!vr.ok)throw new RuntimeException(id+"/"+t.token+"/"+v+" validator "+vr.text());EngineeringSelfAuditGodfather.Result ar=EngineeringSelfAuditGodfather.verify(s,id,t.token);if(!ar.ok)throw new RuntimeException(id+"/"+t.token+"/"+v+" audit "+ar.text());byte[] out=LiveCarSetupCodec.patch(carrier,s,sig);LiveCarSetupCodec.verifyRoundTrip(out,s,sig);f.add(fp(s));count++;}}if(f.size()!=4)throw new RuntimeException(id+"/"+t.token+" variants not distinct");}}}}
  public static void main(String[] a)throws Exception{{List<TrackDNA> tracks=new ArrayList<>();TrackDNA t;{''.join(track_lines)}{''.join(car_lines)}if(count!=864)throw new RuntimeException("count="+count);System.out.println("GODFATHER_RUNTIME_MATRIX_PASS="+count+"/864");}}
}}'''
        (pkg/'LogicVerifier.java').write_text(verifier,encoding='utf-8')
        out=td/'classes';out.mkdir()
        actual=[JAVA/x for x in ['LiveSetupSpec.java','SetupValidator.java','VehicleEngineeringProfile.java','EngineeringProfileStore.java','PhysicsSelfCalculator.java','EngineeringSelfAuditGodfather.java','LiveCarSetupCodec.java']]
        cmd=['javac','--release','17','-encoding','UTF-8','-d',str(out),*map(str,actual),str(pkg/'TrackDNA.java'),str(pkg/'LogicVerifier.java')]
        cp=subprocess.run(cmd,text=True,capture_output=True)
        if cp.returncode!=0: errors.append('javac runtime verifier failed: '+cp.stderr[-4000:])
        else:
            rr=subprocess.run(['java','-cp',str(out),'com.greenbuddy.acevosetupengineer.LogicVerifier'],text=True,capture_output=True)
            if rr.returncode!=0: errors.append('864 runtime matrix failed: '+(rr.stderr+rr.stdout)[-4000:])
            elif 'GODFATHER_RUNTIME_MATRIX_PASS=864/864' not in rr.stdout: errors.append('864 runtime matrix did not report full pass')
            else: notes.append('GODFATHER_RUNTIME_MATRIX_PASS=864/864')

# Basic balanced-source checks: braces and no accidental stale build text.
for p in JAVA.glob('*.java'):
    s=text(p);req(s.count('{')==s.count('}'),'brace count mismatch '+p.name)
req('Multi-Source-Same-Car' not in text(JAVA/'MainActivity.java'),'stale multi-source UI text remains')
req('FIXED FALLBACK' not in all_java,'stale FIXED FALLBACK text remains')

if errors:
    print('VERIFICATION_GODFATHER: FAIL')
    for e in errors: print('ERROR:',e)
    sys.exit(1)
print('VERIFICATION_GODFATHER: PASS')
for n in notes: print(n)
print('LIVE_GATE=3_COMPLETE_ATTEMPTS')
print('STRUCTURE_CARRIERS=6')
print('TRACK_LAYOUTS=36')
print('VARIANTS=4')
print('OLD_SETUP_VALUE_RUNTIME_FALLBACKS=ABSENT')
print('BRANDING=THE_GODFATHER_OF_EVO')
print('COPYRIGHT=GREENBUDDY1976')
