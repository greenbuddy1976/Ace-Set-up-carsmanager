package com.greenbuddy.acevosetupengineer;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Local user content. No GitHub/APK rebuild is required for imported cars, templates or tracks. */
public final class UserContentStore {
    private final Context context; private final File root,templates,db;
    public static final class TemplateData {
        public byte[] bytes; public String sha256="",source="",entry="",version="",signature="",savedAt="";
    }
    public UserContentStore(Context c)throws Exception{
        context=c.getApplicationContext();root=new File(context.getFilesDir(),"acevo_v7_user");templates=new File(root,"templates");db=new File(root,"catalog.json");
        if(!templates.mkdirs()&&!templates.isDirectory())throw new IOException("Cannot create template folder");
        if(!db.exists())saveRoot(emptyRoot());
    }
    private JSONObject emptyRoot()throws Exception{JSONObject r=new JSONObject();r.put("cars",new JSONArray());r.put("tracks",new JSONArray());r.put("templates",new JSONObject());r.put("cache",new JSONObject());return r;}
    private JSONObject loadRoot()throws Exception{try(InputStream in=new FileInputStream(db)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);String s=out.toString(StandardCharsets.UTF_8.name());return s.trim().isEmpty()?emptyRoot():new JSONObject(s);}}
    private void saveRoot(JSONObject o)throws Exception{File tmp=new File(root,"catalog.tmp");try(OutputStream out=new FileOutputStream(tmp)){out.write(o.toString(2).getBytes(StandardCharsets.UTF_8));out.flush();}if(db.exists()&&!db.delete())throw new IOException("Cannot replace catalog");if(!tmp.renameTo(db))throw new IOException("Cannot commit catalog");}
    private static String cleanToken(String s){String t=s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+","_").replaceAll("^_+|_+$","");return t.isEmpty()?"item":t;}
    public List<CarCatalog.CarItem> customCars()throws Exception{
        JSONArray a=loadRoot().getJSONArray("cars");List<CarCatalog.CarItem>x=new ArrayList<>();for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);x.add(new CarCatalog.CarItem(o.getString("id"),o.getString("name"),o.optString("signature",""),false));}return x;
    }
    public List<TrackDNA> customTracks()throws Exception{
        JSONArray a=loadRoot().getJSONArray("tracks");List<TrackDNA>x=new ArrayList<>();for(int i=0;i<a.length();i++)x.add(TrackDNA.fromJson(a.getJSONObject(i)));return x;
    }
    public CarCatalog.CarItem addCustomCar(String name,byte[] template)throws Exception{
        LiveCarSetupCodec.decodeGeneric(template,"Imported car");String sig=LiveCarSetupCodec.extractCarSignature(template);String id="user_"+cleanToken(name)+"_"+Long.toHexString(System.currentTimeMillis());JSONObject r=loadRoot();JSONArray a=r.getJSONArray("cars");JSONObject o=new JSONObject();o.put("id",id);o.put("name",name.trim());o.put("signature",sig);a.put(o);saveRoot(r);saveUserTemplate(id,template,sig,"USER IMPORT","initial template","");return new CarCatalog.CarItem(id,name.trim(),sig,false);
    }
    public TrackDNA addCustomTrack(String name,String profile)throws Exception{
        String token="user_track_"+cleanToken(name)+"_"+Long.toHexString(System.currentTimeMillis());TrackDNA d=TrackDNA.preset(token,name.trim(),profile);JSONObject r=loadRoot();r.getJSONArray("tracks").put(d.toJson());saveRoot(r);return d;
    }
    public void saveUserTemplate(String carId,byte[] bytes,String signature,String source,String entry,String version)throws Exception{
        LiveCarSetupCodec.decodeGeneric(bytes,"Template");File f=new File(templates,carId+".carsetup");write(f,bytes);JSONObject r=loadRoot();JSONObject m=r.getJSONObject("templates");JSONObject o=new JSONObject();o.put("file",f.getName());o.put("sha256",sha256(bytes));o.put("signature",signature==null?"":signature);o.put("source",source==null?"":source);o.put("entry",entry==null?"":entry);o.put("version",version==null?"":version);o.put("savedAt",new Date().toString());m.put(carId,o);saveRoot(r);
    }
    public TemplateData loadUserTemplate(String carId)throws Exception{JSONObject r=loadRoot(),m=r.getJSONObject("templates");if(!m.has(carId))return null;JSONObject o=m.getJSONObject(carId);File f=new File(templates,o.getString("file"));if(!f.isFile())return null;TemplateData t=new TemplateData();t.bytes=read(f);t.sha256=o.optString("sha256",sha256(t.bytes));t.signature=o.optString("signature","");t.source=o.optString("source","USER IMPORT");t.entry=o.optString("entry",f.getName());t.version=o.optString("version","");t.savedAt=o.optString("savedAt","");return t;}
    public String signatureFor(String carId)throws Exception{
        CarCatalog.CarItem b=CarCatalog.builtin(carId);if(b!=null)return b.signature;for(CarCatalog.CarItem c:customCars())if(c.id.equals(carId))return c.signature;TemplateData t=loadUserTemplate(carId);return t==null?"":t.signature;
    }
    private static void write(File f,byte[] b)throws Exception{try(OutputStream out=new FileOutputStream(f)){out.write(b);out.flush();}}
    private static byte[] read(File f)throws Exception{try(InputStream in=new FileInputStream(f)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toByteArray();}}
    public static String sha256(byte[] b)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");byte[] h=d.digest(b);StringBuilder s=new StringBuilder();for(byte x:h)s.append(String.format(Locale.ROOT,"%02x",x));return s.toString();}
}
