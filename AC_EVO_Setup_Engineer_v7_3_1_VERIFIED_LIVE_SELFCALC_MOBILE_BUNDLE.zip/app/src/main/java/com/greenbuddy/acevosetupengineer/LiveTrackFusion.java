package com.greenbuddy.acevosetupengineer;

import java.util.*;

/**
 * Target-track calculation without a donor setup.
 *
 * For every supported vehicle that has one or more genuine LIVE setups for the TARGET layout,
 * each value is first expressed as a normalized deviation from THAT vehicle's own multi-source
 * centre/range. Multiple setups of the same vehicle are median-combined first; then the per-car
 * signals are median-combined across distinct vehicles. Only that dimensionless signal is applied
 * to the selected vehicle's own verified same-car range.
 *
 * Therefore no foreign binary, no foreign absolute setup value and no single reference setup/track
 * is copied into the selected car. Pressure, fuel and electronics are never cross-car fused.
 */
public final class LiveTrackFusion {
    public static final class Observation {public final String carId;public final LiveSetupSpec setup;public Observation(String c,LiveSetupSpec s){carId=c;setup=s;}}
    public static final class Result {public LiveSetupSpec spec;public int samples,cars,fieldsFused;public String evidence="";}
    private LiveTrackFusion(){}
    private interface Get{float v(LiveSetupSpec s);}
    private interface Set{void v(LiveSetupSpec s,float x);}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private static float median(List<Float> x){if(x.isEmpty())return Float.NaN;Collections.sort(x);int n=x.size();return n%2==1?x.get(n/2):(x.get(n/2-1)+x.get(n/2))/2f;}
    private static boolean ok(float x){return Float.isFinite(x);}
    private static float min(VehicleModelStore.Model m,Get g){float z=Float.POSITIVE_INFINITY;for(LiveSetupSpec s:m.calibration){float v=g.v(s);if(ok(v))z=Math.min(z,v);}return z;}
    private static float max(VehicleModelStore.Model m,Get g){float z=Float.NEGATIVE_INFINITY;for(LiveSetupSpec s:m.calibration){float v=g.v(s);if(ok(v))z=Math.max(z,v);}return z;}
    private static Float normalized(VehicleModelStore.Model m,LiveSetupSpec sample,Get g){float sv=g.v(sample),cv=g.v(m.center),lo=min(m,g),hi=max(m,g);if(!ok(sv)||!ok(cv)||!ok(lo)||!ok(hi))return null;float span=hi-lo;if(span<0.000001f)return null;return clamp((sv-cv)/span,-1f,1f);}

    /** Returns true only if >=2 distinct cars contributed a valid value for this field. */
    private static boolean applyField(LiveSetupSpec out,VehicleModelStore.Model selected,List<Observation> obs,VehicleModelStore store,Get g,Set set)throws Exception{
        float slo=min(selected,g),shi=max(selected,g),sc=g.v(selected.center);if(!ok(slo)||!ok(shi)||!ok(sc)||shi-slo<0.000001f)return false;
        LinkedHashMap<String,List<Float>> perCar=new LinkedHashMap<>();
        for(Observation o:obs){
            if(o==null||o.setup==null||o.carId==null||o.carId.isEmpty())continue;
            CarCatalog.CarItem c=CarCatalog.builtin(o.carId);if(c==null||!store.supports(o.carId))continue;
            VehicleModelStore.Model om=store.load(o.carId,c.name,c.signature);Float d=normalized(om,o.setup,g);if(d!=null)perCar.computeIfAbsent(o.carId,k->new ArrayList<>()).add(d);
        }
        ArrayList<Float> carSignals=new ArrayList<>();for(List<Float> xs:perCar.values()){float d=median(xs);if(ok(d))carSignals.add(d);}
        if(carSignals.size()<2)return false;
        float d=median(carSignals);set.v(out,clamp(sc+d*(shi-slo),slo,shi));return true;
    }

    public static Result apply(VehicleModelStore.Model selected,List<Observation> raw,VehicleModelStore store)throws Exception{
        Result r=new Result();r.spec=selected.center.copy();ArrayList<Observation> obs=new ArrayList<>();LinkedHashSet<String> cars=new LinkedHashSet<>();
        for(Observation o:raw){if(o==null||o.setup==null||o.carId==null)continue;if(CarCatalog.builtin(o.carId)==null||!store.supports(o.carId))continue;obs.add(o);cars.add(o.carId);}r.samples=obs.size();r.cars=cars.size();
        if(cars.size()<2){r.evidence="Target-layout data fusion withheld: fewer than 2 distinct supported vehicle models with structured LIVE target-layout metadata. Neutral multi-source same-car model retained; no donor/reference setup substituted.";return r;}
        int n=0;
        if(applyField(r.spec,selected,obs,store,s->s.brakeBias,(s,v)->s.brakeBias=v))n++;
        if(applyField(r.spec,selected,obs,store,s->s.diffPreload,(s,v)->s.diffPreload=v))n++;
        for(int i=0;i<2;i++){final int k=i;if(applyField(r.spec,selected,obs,store,s->s.arb[k],(s,v)->s.arb[k]=v))n++;}
        for(int i=0;i<4;i++){final int k=i;
            if(applyField(r.spec,selected,obs,store,s->s.camber[k],(s,v)->s.camber[k]=v))n++;
            if(applyField(r.spec,selected,obs,store,s->s.toe[k],(s,v)->s.toe[k]=v))n++;
            if(applyField(r.spec,selected,obs,store,s->s.spring[k],(s,v)->s.spring[k]=v))n++;
            if(applyField(r.spec,selected,obs,store,s->s.bumpstopRange[k],(s,v)->s.bumpstopRange[k]=v))n++;
            if(applyField(r.spec,selected,obs,store,s->s.bumpstopRate[k],(s,v)->s.bumpstopRate[k]=v))n++;
            if(applyField(r.spec,selected,obs,store,s->s.slowBump[k],(s,v)->s.slowBump[k]=v))n++;
            if(applyField(r.spec,selected,obs,store,s->s.fastBump[k],(s,v)->s.fastBump[k]=v))n++;
            if(applyField(r.spec,selected,obs,store,s->s.slowRebound[k],(s,v)->s.slowRebound[k]=v))n++;
            if(applyField(r.spec,selected,obs,store,s->s.fastRebound[k],(s,v)->s.fastRebound[k]=v))n++;
        }
        for(int i=0;i<2;i++){final int k=i;if(applyField(r.spec,selected,obs,store,s->s.rideHeight[k],(s,v)->s.rideHeight[k]=v))n++;}
        r.fieldsFused=n;
        r.evidence="LIVE target-layout DATA FUSION: "+obs.size()+" valid setup observations from "+cars.size()+" distinct supported vehicle models; per-car medians were calculated first, then a cross-car median of normalized deviations. "+n+" selected-car fields received a target-layout signal. No donor file, no single reference setup/track, no foreign binary and no foreign absolute setup value was copied. Pressure, fuel and electronics were excluded from cross-car fusion.";
        return r;
    }
}
