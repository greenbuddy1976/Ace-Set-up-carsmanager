package com.greenbuddy.acevosetupengineer;

import java.util.*;

/** Optional conservative driver-feedback tuning; no donor/setup database is consulted. */
public final class LiveFineTuningV7 {
    public static final String NONE="Kein Fine-Tuning";
    public static final String[] PROBLEMS={NONE,"Heck beim Bremsen instabil","Untersteuern beim Einlenken","Heck am Kurvenausgang nervös","Springt über Kerbs / Kuppen","Auto ist zu träge","Reifenverschleiß zu hoch","Highspeed-Heck nervös","Mehr Topspeed"};
    public static class Result{public LiveSetupSpec spec;public String summary="";}
    private LiveFineTuningV7(){}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}private static float r(float v,int d){float p=(float)Math.pow(10,d);return Math.round(v*p)/p;}private static float k(int intensity){return Math.max(1,Math.min(3,intensity))/3f;}
    public static String detect(String text,String fallback){if(text==null||text.trim().isEmpty())return fallback;String t=text.toLowerCase(Locale.ROOT);if((t.contains("brems")||t.contains("anbrems"))&&(t.contains("heck")||t.contains("dreht")||t.contains("instabil")))return PROBLEMS[1];if(t.contains("unterste"))return PROBLEMS[2];if((t.contains("ausgang")||t.contains("gas"))&&(t.contains("heck")||t.contains("nerv")))return PROBLEMS[3];if(t.contains("kerb")||t.contains("kuppe")||t.contains("bodenwelle")||t.contains("spring"))return PROBLEMS[4];if(t.contains("träge")||t.contains("traege"))return PROBLEMS[5];if(t.contains("verschlei"))return PROBLEMS[6];if(t.contains("highspeed")&&t.contains("heck"))return PROBLEMS[7];if(t.contains("topspeed")||t.contains("endgeschwindigkeit"))return PROBLEMS[8];return fallback;}
    public static Result apply(LiveSetupSpec in,String problem,int intensity){Result z=new Result();LiveSetupSpec s=in.copy();z.spec=s;if(problem==null||NONE.equals(problem)){z.summary="Fine-Tuning aus";return z;}float x=k(intensity);List<String>n=new ArrayList<>();
        if(PROBLEMS[1].equals(problem)){s.brakeBias=r(clamp(s.brakeBias+.35f*x,40,80),1);if(s.absPresent)s.abs=clamp(s.abs+1*x,0,30);s.toe[2]=r(s.toe[2]+.012f*x,3);s.toe[3]=r(s.toe[3]+.012f*x,3);n.add("mehr Brems-/Heckstabilität");}
        else if(PROBLEMS[2].equals(problem)){s.toe[0]=r(s.toe[0]-.010f*x,3);s.toe[1]=r(s.toe[1]-.010f*x,3);if(Float.isFinite(s.arb[0]))s.arb[0]*=(1f-.04f*x);if(Float.isFinite(s.arb[1]))s.arb[1]*=(1f+.04f*x);n.add("mehr Einlenkrotation");}
        else if(PROBLEMS[3].equals(problem)){if(s.tcPresent)s.tc=clamp(s.tc+1*x,0,30);s.toe[2]=r(s.toe[2]+.012f*x,3);s.toe[3]=r(s.toe[3]+.012f*x,3);if(Float.isFinite(s.diffPreload))s.diffPreload=r(clamp(s.diffPreload+10*x,0,5000),0);n.add("mehr Traktion am Ausgang");}
        else if(PROBLEMS[4].equals(problem)){s.rideHeight[0]=r(s.rideHeight[0]+2*x,1);s.rideHeight[1]=r(s.rideHeight[1]+2*x,1);for(int i=0;i<4;i++){if(Float.isFinite(s.fastBump[i]))s.fastBump[i]*=(1f-.07f*x);if(Float.isFinite(s.fastRebound[i]))s.fastRebound[i]*=(1f-.05f*x);}n.add("mehr Kerb-/Kuppenreserve");}
        else if(PROBLEMS[5].equals(problem)){s.toe[0]=r(s.toe[0]-.008f*x,3);s.toe[1]=r(s.toe[1]-.008f*x,3);if(Float.isFinite(s.arb[1]))s.arb[1]*=(1f+.04f*x);n.add("agileres Ansprechen");}
        else if(PROBLEMS[6].equals(problem)){for(int i=0;i<4;i++)s.camber[i]=r(s.camber[i]+.10f*x,2);n.add("weniger aggressive Camber-Nutzung");}
        else if(PROBLEMS[7].equals(problem)){s.toe[2]=r(s.toe[2]+.010f*x,3);s.toe[3]=r(s.toe[3]+.010f*x,3);if(s.wingVerified&&s.wing!=null)s.wing=clamp(s.wing+1*x,0,20);n.add("mehr Highspeed-Heckstabilität");}
        else if(PROBLEMS[8].equals(problem)){if(s.wingVerified&&s.wing!=null)s.wing=clamp(s.wing-1*x,0,20);n.add("weniger Flügel für Topspeed");}
        SetupValidator.Result vr=SetupValidator.check(s);if(!vr.ok)throw new IllegalArgumentException("Fine-Tuning validation failed: "+vr.text());z.summary="• "+String.join("\n• ",n);return z;}
}
