package com.greenbuddy.acevosetupengineer;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.util.zip.*;

/**
 * v7.3.1 source/calculation layer.
 * 1) Fresh exact car+layout search across the complete discovered RacePlace archive and SetupsMarket index.
 * 2) SetupsMarket exact layout matching uses structured detail metadata (car · track · session), never the free-text title.
 * 3) If no exact binary is accepted, calculate from a synthetic multi-source same-car median model plus an optional
 *    target-layout signal derived from normalized medians across multiple supported cars.
 * No donor file, nearest-track candidate, fixed reference track or Track-DNA fallback exists in this path.
 */
public final class LiveSetupSourceManager {
    public static final String RACEPLACE_PAGE="https://raceplace.racing/downloads/";
    public static final String SETUPSMARKET_PAGE="https://setupsmarket.com/";
    private static final int MAX_ARCHIVE_BYTES=25*1024*1024,MAX_SETUP_BYTES=2*1024*1024,MAX_ZIP_ENTRIES=6000;
    private static final long MEMORY_CACHE_MS=15*60*1000L;
    public interface Callback{void done(SourceResult result);}

    public static class SourceResult{
        public boolean online=false,exact=false,calculated=false,usedCache=false,freshLive=false,liveCoverageComplete=true;
        public String provider="",sourceVersion="",downloadUrl="",sourcePage="",sha256="",archiveSha256="",hashScope="",entryName="",checkedAt="",error="",confidence="",evidence="";
        public int setupEntries=0,signatureMatches=0,sameCarCandidates=0,vehicleModelSources=0,trackFusionSamples=0,trackFusionCars=0,marketExpected=0,marketDiscovered=0;
        public byte[] setupBytes=null; public LiveSetupSpec calculatedBase=null;
        public String compact(){
            if(exact)return "✅ "+(freshLive?"FRISCH LIVE · ":"")+"EXACT · "+provider+" · "+entryName;
            if(calculated)return "🧮 SELF CALCULATED · KEIN SPENDER · "+provider+(liveCoverageComplete?"":" · ⚠ LIVE-COVERAGE");
            return online?"LIVE · keine sichere Berechnungsbasis":"OFFLINE · keine sichere Berechnungsbasis";
        }
    }
    private static class TrackAliases{List<String> aliases=new ArrayList<>(),reject=new ArrayList<>();}
    private static class Candidate{String name,provider="",version="",sourcePage="",downloadUrl="",sha="";byte[] bytes;int exactScore=-1;Candidate(String n,byte[] b){name=n;bytes=b;}}
    private static class Card{String id="",context="";int exactScore=-1,first=-1,last=-1;}
    private static class Discovery{String url,version;Discovery(String u,String v){url=u;version=v;}}
    private static class Scan {boolean online=false,coverageComplete=true;String archiveSha="",version="",error="";int entries=0,expectedEntries=0,sameCar=0;Candidate exact=null;final List<LiveTrackFusion.Observation> trackObs=new ArrayList<>();}

    private final Context context;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Map<String,TrackAliases> tracks=new LinkedHashMap<>();
    private final VehicleModelStore models;
    private String cachedUrl="",cachedSha="";private byte[] cachedZip=null;private long cachedAt=0;

    public LiveSetupSourceManager(Context c,UserContentStore ignored)throws Exception{
        context=c.getApplicationContext();models=new VehicleModelStore(context);
        JSONObject root=new JSONObject(readAsset("live_source_aliases.json"));JSONObject tt=root.getJSONObject("tracks");Iterator<String> it=tt.keys();
        while(it.hasNext()){String token=it.next();JSONObject o=tt.getJSONObject(token);TrackAliases a=new TrackAliases();JSONArray aa=o.getJSONArray("aliases");for(int i=0;i<aa.length();i++)a.aliases.add(normalize(aa.getString(i)));JSONArray rr=o.optJSONArray("reject");if(rr!=null)for(int i=0;i<rr.length();i++)a.reject.add(normalize(rr.getString(i)));tracks.put(token,a);}
    }
    public VehicleModelStore modelStore(){return models;}
    public void findSmart(String carId,String carName,String signature,String trackToken,String trackLabel,Callback cb){findSmart(carId,carName,signature,trackToken,trackLabel,false,cb);}
    public void findSmart(String carId,String carName,String signature,String trackToken,String trackLabel,boolean forceFresh,Callback cb){executor.execute(()->{SourceResult r;try{r=findSmartSync(carId,carName,signature,trackToken,trackLabel,forceFresh);}catch(Exception e){r=new SourceResult();r.error=e.getClass().getSimpleName()+": "+safe(e.getMessage());}SourceResult out=r;main.post(()->cb.done(out));});}

    SourceResult findSmartSync(String carId,String carName,String signature,String trackToken,String trackLabel,boolean forceFresh)throws Exception{
        String checked=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.GERMANY).format(new Date());TrackAliases ta=aliasesFor(trackToken,trackLabel);Scan race=new Scan(),market=new Scan();
        try{race=scanRacePlace(carId,carName,signature,ta,forceFresh);}catch(Exception e){race.coverageComplete=false;race.error=safe(e.getMessage());}
        try{market=scanSetupsMarket(carId,carName,signature,ta,forceFresh);}catch(Exception e){market.coverageComplete=false;market.error=safe(e.getMessage());}
        boolean liveComplete=race.online&&race.coverageComplete&&market.online&&market.coverageComplete;

        Candidate exact=bestExact(race.exact,market.exact);
        if(exact!=null){
            SourceResult r=fromExact(exact,checked,forceFresh);r.online=true;r.archiveSha256=race.archiveSha;r.setupEntries=race.entries+market.entries;r.sameCarCandidates=race.sameCar+market.sameCar;r.signatureMatches=r.sameCarCandidates;r.marketExpected=market.expectedEntries;r.marketDiscovered=market.entries;r.liveCoverageComplete=liveComplete;
            r.evidence="LIVE EXACT accepted before any calculation. RacePlace archive scan: "+race.entries+" .carsetup entries. SetupsMarket discovery: "+market.entries+(market.expectedEntries>0?" / "+market.expectedEntries:"")+" unique cards. Target layout was decided from structured detail metadata (car · track · session · game version), not the free-text setup title. Accepted binary passed same-car signature and decoder validation: "+exact.provider+" / "+exact.name+".";
            return r;
        }

        if(!models.supports(carId)){
            SourceResult r=new SourceResult();r.checkedAt=checked;r.online=race.online||market.online;r.liveCoverageComplete=liveComplete;r.marketExpected=market.expectedEntries;r.marketDiscovered=market.entries;r.error="No exact car+layout binary and no multi-source vehicle model for this custom car. Calculation is blocked rather than using a donor/reference setup.";return r;
        }

        VehicleModelStore.Model model=models.load(carId,carName,signature);
        ArrayList<LiveTrackFusion.Observation> obs=new ArrayList<>();
        for(LiveTrackFusion.Observation o:race.trackObs)if(o!=null&&!carId.equals(o.carId))obs.add(o);
        for(LiveTrackFusion.Observation o:market.trackObs)if(o!=null&&!carId.equals(o.carId))obs.add(o);
        LiveTrackFusion.Result fused=LiveTrackFusion.apply(model,obs,models);

        LiveSetupSpec base=fused.spec;base.carId=carId;base.carName=carName;base.trackToken=trackToken;base.trackLabel=trackLabel;base.sourceEntry="vehicle_models/"+carId+".carsetup";base.sourceVersion="7.3.1 multi-source median model";base.sourceSha256=model.sha256;base.vehicleModelSha256=model.sha256;base.vehicleModelSources=model.sourceCount;base.trackFusionSamples=fused.samples;base.trackFusionCars=fused.cars;base.calculationEvidence=fused.evidence;
        SourceResult r=new SourceResult();r.checkedAt=checked;r.online=race.online||market.online;r.freshLive=forceFresh&&r.online;r.calculated=true;r.provider="SELF-CALC · MULTI-SOURCE SAME-CAR MODEL + TARGET-LAYOUT DATA FUSION";r.sourceVersion="7.3.1";r.sourcePage="EMBEDDED SHA-256 MODEL + STRUCTURED LIVE TARGET-LAYOUT OBSERVATIONS";r.entryName=base.sourceEntry;r.setupBytes=model.bytes;r.sha256=model.sha256;r.hashScope="SYNTHETIC SAME-CAR MEDIAN MODEL";r.calculatedBase=base;r.vehicleModelSources=model.sourceCount;r.trackFusionSamples=fused.samples;r.trackFusionCars=fused.cars;r.sameCarCandidates=race.sameCar+market.sameCar;r.marketExpected=market.expectedEntries;r.marketDiscovered=market.entries;r.liveCoverageComplete=liveComplete;r.confidence=(fused.cars>=2?"DATA-FUSED":"MODEL-ONLY")+(liveComplete?"":" / LIVE-COVERAGE-WARN");
        r.evidence="No exact selected-car+layout binary was accepted. SELF CALCULATION starts from a synthetic component-median vehicle model built from "+model.sourceCount+" SHA-256-verified genuine same-car calibration files; no single source file or source track is selected. "+fused.evidence+" SetupsMarket index coverage="+market.entries+(market.expectedEntries>0?"/"+market.expectedEntries:"")+"; coverage gate="+(market.coverageComplete?"PASS":"INCOMPLETE")+". Scan errors: RacePlace="+empty(race.error)+"; SetupsMarket="+empty(market.error)+".";
        if(!liveComplete)r.error="LIVE exact-search coverage could not be proven complete. Calculation is produced but explicitly marked LIVE-COVERAGE-WARN; it must not claim that no exact setup exists.";
        else if(fused.cars<2)r.error="No exact online setup and fewer than 2 distinct supported target-layout vehicle models; neutral multi-source same-car model used. No donor/reference setup was invented.";
        return r;
    }

    private static Candidate bestExact(Candidate a,Candidate b){if(a==null)return b;if(b==null)return a;return b.exactScore>a.exactScore?b:a;}
    private SourceResult fromExact(Candidate c,String checked,boolean fresh)throws Exception{SourceResult r=new SourceResult();r.checkedAt=checked;r.provider=c.provider;r.sourceVersion=c.version;r.sourcePage=c.sourcePage;r.downloadUrl=c.downloadUrl;r.entryName=c.name;r.setupBytes=c.bytes;r.sha256=c.sha==null||c.sha.isEmpty()?UserContentStore.sha256(c.bytes):c.sha;r.hashScope="SETUP";r.exact=true;r.online=true;r.freshLive=fresh;r.confidence="HIGH";return r;}

    private Scan scanRacePlace(String carId,String carName,String signature,TrackAliases ta,boolean forceFresh)throws Exception{
        Scan out=new Scan();String page=fetchText(RACEPLACE_PAGE,2*1024*1024,forceFresh);out.online=true;Discovery d=discoverRacePlace(page);out.version=d.version;byte[] zip;
        if(!forceFresh&&cachedZip!=null&&d.url.equals(cachedUrl)&&System.currentTimeMillis()-cachedAt<MEMORY_CACHE_MS){zip=cachedZip;}else{zip=fetchBytes(d.url,MAX_ARCHIVE_BYTES,forceFresh);cachedZip=zip;cachedUrl=d.url;cachedSha=UserContentStore.sha256(zip);cachedAt=System.currentTimeMillis();}out.archiveSha=cachedSha;
        try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(zip))){ZipEntry e;int all=0;while((e=zin.getNextEntry())!=null){if(++all>MAX_ZIP_ENTRIES)throw new IOException("ZIP entry limit exceeded");if(e.isDirectory()||!e.getName().toLowerCase(Locale.ROOT).endsWith(".carsetup"))continue;out.entries++;byte[] b=readZipEntry(zin,MAX_SETUP_BYTES);String norm=normalize(e.getName());int ts=trackScore(norm,ta);String known=LiveCarSetupCodec.identifyKnownCar(b);
                if(!known.isEmpty()&&ts>=0){try{CarCatalog.CarItem ci=CarCatalog.builtin(known);if(ci!=null){LiveSetupSpec x=LiveCarSetupCodec.decode(b,known,ci.name,ci.signature);out.trackObs.add(new LiveTrackFusion.Observation(known,x));}}catch(Exception ignored){}}
                if(!validForCar(b,carId,signature))continue;out.sameCar++;try{LiveCarSetupCodec.decode(b,carId,carName,signature);}catch(Exception ex){continue;}if(ts>=0){Candidate c=new Candidate(e.getName(),b);c.provider="RacePlace/DTVR";c.version=d.version;c.sourcePage=RACEPLACE_PAGE;c.downloadUrl=d.url;c.sha=UserContentStore.sha256(b);c.exactScore=ts;if(out.exact==null||c.exactScore>out.exact.exactScore)out.exact=c;}
            }}out.coverageComplete=true;return out;
    }

    private Scan scanSetupsMarket(String carId,String carName,String signature,TrackAliases ta,boolean forceFresh)throws Exception{
        Scan out=new Scan();String html=fetchText(SETUPSMARKET_PAGE,8*1024*1024,forceFresh);out.online=true;out.expectedEntries=expectedSetupCount(html);List<Card> all=allCards(html,ta);out.entries=all.size();out.coverageComplete=out.expectedEntries>0&&out.entries>=out.expectedEntries;String carNorm=normalize(carName);
        // No numeric cap. Card context is only a prefilter; structured detail metadata is the authority.
        for(Card card:all){if(!card.context.contains(carNorm))continue;out.sameCar++;Candidate c=loadExactMarket(card,carId,carName,signature,ta,forceFresh);if(c!=null&&(out.exact==null||c.exactScore>out.exact.exactScore))out.exact=c;}
        // Keep every valid target-layout observation. Fusion later median-combines multiple setups within each car.
        for(Card card:all){if(card.exactScore<0)continue;LiveTrackFusion.Observation o=loadTrackObservation(card,ta,forceFresh);if(o!=null)out.trackObs.add(o);}return out;
    }

    private Candidate loadExactMarket(Card card,String carId,String carName,String signature,TrackAliases ta,boolean forceFresh){
        try{String detailUrl="https://setupsmarket.com/setup/"+card.id;String detail=fetchText(detailUrl,2*1024*1024,forceFresh),plain=stripHtml(detail);int structuredScore=structuredTrackScore(plain,carName,ta);if(structuredScore<0)return null;String version=findVersion(plain),filename=findFilename(plain),download=detailUrl+"/download";byte[] b=fetchBytes(download,MAX_SETUP_BYTES,forceFresh);if(!validForCar(b,carId,signature))return null;LiveCarSetupCodec.decode(b,carId,carName,signature);Candidate c=new Candidate((filename.isEmpty()?"community.carsetup":filename)+" · setup/"+card.id,b);c.provider="SetupsMarket community";c.version=version;c.sourcePage=detailUrl;c.downloadUrl=download;c.sha=UserContentStore.sha256(b);c.exactScore=structuredScore;return c;}catch(Exception ignored){return null;}
    }
    private LiveTrackFusion.Observation loadTrackObservation(Card card,TrackAliases ta,boolean forceFresh){
        try{String detailUrl="https://setupsmarket.com/setup/"+card.id;String detail=fetchText(detailUrl,2*1024*1024,forceFresh),plain=stripHtml(detail);String structuredCar=structuredSupportedCarForTrack(plain,ta);if(structuredCar.isEmpty())return null;CarCatalog.CarItem ci=CarCatalog.builtin(structuredCar);if(ci==null||!models.supports(structuredCar))return null;byte[] b=fetchBytes(detailUrl+"/download",MAX_SETUP_BYTES,forceFresh);String binaryCar=LiveCarSetupCodec.identifyKnownCar(b);if(!structuredCar.equals(binaryCar))return null;LiveSetupSpec x=LiveCarSetupCodec.decode(b,structuredCar,ci.name,ci.signature);return new LiveTrackFusion.Observation(structuredCar,x);}catch(Exception ignored){return null;}
    }

    /** Bounded card chunks prevent neighbouring cards from contaminating the prefilter. */
    private List<Card> allCards(String html,TrackAliases ta){
        LinkedHashMap<String,int[]> spans=new LinkedHashMap<>();Pattern p=Pattern.compile("(?:https?://(?:www\\.)?setupsmarket\\.com)?/?setup/([0-9a-fA-F-]{36})",Pattern.CASE_INSENSITIVE);Matcher m=p.matcher(html);
        while(m.find()){String id=m.group(1).toLowerCase(Locale.ROOT);int[] sp=spans.get(id);if(sp==null)spans.put(id,new int[]{m.start(),m.end()});else sp[1]=Math.max(sp[1],m.end());}
        List<Map.Entry<String,int[]>> u=new ArrayList<>(spans.entrySet());u.sort(Comparator.comparingInt(e->e.getValue()[0]));ArrayList<Card> out=new ArrayList<>();
        for(int i=0;i<u.size();i++){Map.Entry<String,int[]> e=u.get(i);int a=e.getValue()[0],b=i+1<u.size()?u.get(i+1).getValue()[0]:html.length();if(b<=a)b=Math.min(html.length(),e.getValue()[1]+5000);Card c=new Card();c.id=e.getKey();c.first=a;c.last=b;c.context=normalize(stripHtml(html.substring(a,b)));c.exactScore=trackScore(c.context,ta);out.add(c);}return out;
    }

    private static int expectedSetupCount(String html){String p=stripHtml(html);Matcher m=Pattern.compile("(?i)(\\d{1,5})\\s+Setups\\b").matcher(p);return m.find()?Integer.parseInt(m.group(1)):0;}

    /**
     * Authoritative SetupsMarket layout match. The page currently exposes metadata as:
     * "Car · Track · Race/Qualifying/... · game vX". A title containing "Bathurst" cannot pass if the
     * structured track says e.g. "Brands Hatch GP".
     */
    private static int structuredTrackScore(String plain,String carName,TrackAliases ta){return SetupMetadataMatcher.structuredTrackScore(plain,carName,ta.aliases,ta.reject);}
    private static String structuredSupportedCarForTrack(String plain,TrackAliases ta){for(CarCatalog.CarItem c:CarCatalog.builtins())if(structuredTrackScore(plain,c.name,ta)>=0)return c.id;return "";}

    private boolean validForCar(byte[] b,String carId,String signature){try{return LiveCarSetupCodec.signatureMatches(b,carId,signature);}catch(Exception e){return false;}}
    private TrackAliases aliasesFor(String token,String label){TrackAliases a=tracks.get(token);if(a!=null)return a;TrackAliases x=new TrackAliases();String n=normalize(label);if(!n.isEmpty())x.aliases.add(n);String t=normalize(token);if(!t.isEmpty()&&!t.equals(n))x.aliases.add(t);return x;}
    private static Discovery discoverRacePlace(String html)throws Exception{String h=html.replace("&amp;","&");Pattern p=Pattern.compile("href\\s*=\\s*[\"']([^\"']*/download/\\d+/[^\"']*)[\"']",Pattern.CASE_INSENSITIVE);Matcher m=p.matcher(h);String bestUrl=null,bestContext=null;while(m.find()){int a=Math.max(0,m.start()-900),b=Math.min(h.length(),m.end()+1600);String ctx=h.substring(a,b),lc=ctx.toLowerCase(Locale.ROOT);if(lc.contains("raceplace-ace-baseline-setups")||lc.contains("assetto corsa evo free baseline setups")){bestUrl=m.group(1);bestContext=ctx;break;}}if(bestUrl==null)throw new IOException("AC EVO baseline download link not found on RacePlace page");String version="CURRENT";Matcher vm=Pattern.compile("V(\\d+\\.\\d+(?:\\.\\d+)?)",Pattern.CASE_INSENSITIVE).matcher(bestContext==null?"":bestContext);if(vm.find())version=vm.group(1);return new Discovery(new URI(RACEPLACE_PAGE).resolve(bestUrl).toString(),version);}
    private static int trackScore(String n,TrackAliases ta){for(String bad:ta.reject)if(!bad.isEmpty()&&n.contains(bad))return -1;int score=-1;for(String a:ta.aliases)if(!a.isEmpty()&&n.contains(a))score=Math.max(score,100+a.length());return score;}
    private static String findVersion(String text){Matcher m=Pattern.compile("game\\s*v?([0-9]+(?:\\.[0-9]+){1,3})",Pattern.CASE_INSENSITIVE).matcher(text);return m.find()?m.group(1):"UNKNOWN";}
    private static String findFilename(String text){Matcher m=Pattern.compile("file\\s*:\\s*(.{1,180}?\\.carsetup)",Pattern.CASE_INSENSITIVE).matcher(text);return m.find()?m.group(1).trim():"";}
    private byte[] readAssetBytes(String name)throws Exception{try(InputStream in=context.getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toByteArray();}}
    private String readAsset(String name)throws Exception{return new String(readAssetBytes(name),StandardCharsets.UTF_8);}
    private static String fetchText(String url,int max,boolean noCache)throws Exception{return new String(fetchBytes(url,max,noCache),StandardCharsets.UTF_8);}
    private static byte[] fetchBytes(String url,int max,boolean noCache)throws Exception{URL u=new URL(url);URLConnection uc=u.openConnection();uc.setUseCaches(!noCache);uc.setConnectTimeout(12000);uc.setReadTimeout(30000);uc.setRequestProperty("User-Agent","Mozilla/5.0 (Android) AC-EVO-Setup-Engineer-v7.3.1/7.3.1");uc.setRequestProperty("Accept-Language","en-US,en;q=0.8,de;q=0.6");if(noCache){uc.setRequestProperty("Cache-Control","no-cache, no-store, max-age=0");uc.setRequestProperty("Pragma","no-cache");}if(uc instanceof HttpURLConnection){HttpURLConnection h=(HttpURLConnection)uc;h.setInstanceFollowRedirects(true);int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code+" from "+u.getHost());}int len=uc.getContentLength();if(len>max)throw new IOException("Download too large: "+len);try(InputStream in=uc.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[16384];int n,total=0;while((n=in.read(b))>0){total+=n;if(total>max)throw new IOException("Download exceeds safety limit");out.write(b,0,n);}return out.toByteArray();}}
    private static byte[] readZipEntry(InputStream in,int max)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n,total=0;while((n=in.read(b))>0){total+=n;if(total>max)throw new IOException(".carsetup ZIP entry too large");out.write(b,0,n);}return out.toByteArray();}
    private static String normalize(String s){String x=Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);return x.replaceAll("[^a-z0-9]+","");}
    private static String stripHtml(String s){return s==null?"":s.replaceAll("(?is)<script.*?</script>"," ").replaceAll("(?is)<style.*?</style>"," ").replaceAll("(?is)<[^>]+>"," ").replace("&nbsp;"," ").replace("&amp;","&").replace("&middot;","·").replace("&#183;","·");}
    private static String safe(String s){return s==null?"":s.replace('\n',' ').replace('\r',' ');}private static String empty(String s){return s==null||s.isEmpty()?"none":s;}
}
