#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, re, subprocess, tempfile, textwrap, sys, shutil

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'app/src/main/assets'
JAVA=ROOT/'app/src/main/java/com/greenbuddy/acevosetupengineer'
errors=[]; notes=[]

def req(cond,msg):
    if not cond: errors.append(msg)
def txt(p): return p.read_text(encoding='utf-8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,**kw):
    return subprocess.run(cmd,check=True,text=True,capture_output=True,**kw)

# ---------- Release/version ----------
bg=txt(ROOT/'app/build.gradle')
req('versionCode 13' in bg,'versionCode must be 13')
req('versionName "7.3.1-verified-live-selfcalc-release"' in bg,'versionName mismatch')
req('v7.3.1' in txt(JAVA/'MainActivity.java'),'MainActivity version text missing')
req('v7.3.1' in txt(ROOT/'app/src/main/AndroidManifest.xml'),'Android label version missing')

# ---------- Java lexical/syntax guard ----------
def java_lexical_errors(path):
    src=txt(path); out=[]; i=0; n=len(src); state='code'; start_line=1; line=1
    while i<n:
        c=src[i]; d=src[i+1] if i+1<n else ''
        if state=='code':
            if c=='/' and d=='/': state='line_comment'; i+=2; continue
            if c=='/' and d=='*': state='block_comment'; i+=2; continue
            if c=='"': state='string'; start_line=line; i+=1; continue
            if c=="'": state='char'; start_line=line; i+=1; continue
        elif state=='line_comment':
            if c=='\n': state='code'
        elif state=='block_comment':
            if c=='*' and d=='/': state='code'; i+=2; continue
        elif state in ('string','char'):
            quote='"' if state=='string' else "'"
            if c=='\\':
                i+=2; continue
            if c==quote:
                state='code'; i+=1; continue
            if c=='\n' or c=='\r':
                out.append(f'{path.name}:{start_line}: unescaped newline in {state} literal')
                state='code'
        if c=='\n': line+=1
        i+=1
    if state in ('string','char','block_comment'):
        out.append(f'{path.name}:{start_line}: unterminated {state}')
    return out
for jp in JAVA.glob('*.java'):
    for e in java_lexical_errors(jp): errors.append('Java lexical check: '+e)

# javac parser smoke-test: unresolved Android symbols are expected here, syntax diagnostics are not.
ma=JAVA/'MainActivity.java'
try:
    rr=subprocess.run(['javac','-proc:none','-encoding','UTF-8',str(ma)],text=True,capture_output=True)
    diag=(rr.stdout or '')+'\n'+(rr.stderr or '')
    forbidden=('unclosed string literal','illegal character','not a statement',"';' expected","')' expected",'reached end of file while parsing')
    for token in forbidden:
        req(token not in diag,f'MainActivity javac syntax smoke failed: {token}')
except Exception as e:
    errors.append('MainActivity javac syntax smoke could not run: '+str(e))

# ---------- Track catalog consistency ----------
cat=json.loads(txt(ASSETS/'track_catalog.json')); order=json.loads(txt(ASSETS/'track_order.json')); aliases=json.loads(txt(ASSETS/'live_source_aliases.json'))['tracks']
cat_tokens=[x['token'] for x in cat]
req(len(cat_tokens)==36 and len(set(cat_tokens))==36,'track_catalog must contain 36 unique tokens')
req(order==cat_tokens,'track_order must exactly match track_catalog order')
req(set(aliases)==set(cat_tokens),'live_source_aliases track tokens differ from catalog')
for token,o in aliases.items():
    aa=o.get('aliases',[])
    req(aa and all(isinstance(x,str) and x.strip() for x in aa),f'{token}: aliases missing/blank')
req('3a' not in aliases['paul_ricard_3a']['aliases'] and '3c' not in aliases['paul_ricard_3c']['aliases'],'unsafe short Paul Ricard aliases 3a/3c present')

# ---------- No legacy fallback / magic path ----------
all_java='\n'.join(txt(p) for p in JAVA.glob('*.java'))
req('track_dna.json' not in all_java.lower(),'legacy numeric track_dna asset referenced')
req('fixed_fallback' not in all_java.lower(),'fixed fallback path/text remains')
req('nearest-candidate' not in all_java.lower() and 'candidateRank' not in all_java,'nearest-candidate fallback code remains')
req('all.get(0)' not in txt(JAVA/'LiveSetupSourceManager.java'),'first candidate selection fallback remains')
req(re.search(r'pressure\s*\[[^\]]+\]\s*=\s*27(?:\.0+)?f?',all_java,re.I) is None,'hard-coded 27 PSI assignment found')

# ---------- LIVE search guardrails ----------
sm=txt(JAVA/'LiveSetupSourceManager.java')
req('race.online&&race.coverageComplete&&market.online&&market.coverageComplete' in sm,'complete-live claim does not require both sources online+complete')
req('out.expectedEntries>0&&out.entries>=out.expectedEntries' in sm,'SetupsMarket unknown count must not be treated as complete')
req('No numeric cap' in sm,'SetupsMarket no-cap evidence missing')
req('SetupMetadataMatcher.structuredTrackScore' in sm,'structured metadata gate not wired into source manager')
req('LiveCarSetupCodec.decode(b,carId,carName,signature)' in sm,'downloaded exact binary decoder gate missing')
req('validForCar(b,carId,signature)' in sm,'same-car binary signature gate missing')
req('coverage could not be proven complete' in sm,'LIVE coverage warning path missing')
req('!carId.equals(o.carId)' in sm,'selected car exact/observation separation missing')
req('vehicle_models/' in sm and 'MULTI-SOURCE SAME-CAR MODEL' in sm,'multi-source self-calc path missing')

# ---------- Actual structured-metadata regression test ----------
matcher=JAVA/'SetupMetadataMatcher.java'
with tempfile.TemporaryDirectory(prefix='acevo_meta_') as td:
    td=Path(td); out=td/'out';out.mkdir()
    test=td/'MetadataVerifier.java'
    test.write_text(textwrap.dedent(r'''
        import com.greenbuddy.acevosetupengineer.SetupMetadataMatcher;
        import java.util.*;
        public class MetadataVerifier {
          public static void main(String[] a){
            List<String> al=Arrays.asList("mountpanorama","bathurst","mountpanoramagp");
            List<String> re=Collections.emptyList();
            String good="BMW M4 GT3 Evo · Mount Panorama · Race · Dry · game v0.7.1";
            String bad="BMW M4 GT3 EVO BATHURS\nBMW M4 GT3 Evo · Brands Hatch GP · Race · game v0.7.1";
            String other="Ferrari 288 GTO · Nurburgring Touristenfahrten · Other · game v0.7.1";
            if(SetupMetadataMatcher.structuredTrackScore(good,"BMW M4 GT3 Evo",al,re)<0) throw new RuntimeException("good Mount Panorama rejected");
            if(SetupMetadataMatcher.structuredTrackScore(bad,"BMW M4 GT3 Evo",al,re)>=0) throw new RuntimeException("free-text Bathurst title overrode structured Brands Hatch metadata");
            if(SetupMetadataMatcher.structuredTrackScore(other,"Ferrari 288 GTO",Arrays.asList("touristenfahrten"),Collections.emptyList())<0) throw new RuntimeException("Other session metadata rejected");
            System.out.println("STRUCTURED_METADATA_REGRESSION_PASS");
          }
        }
    '''),encoding='utf-8')
    try:
        run(['javac','-encoding','UTF-8','-d',str(out),str(matcher),str(test)])
        rr=run(['java','-cp',str(out),'MetadataVerifier'])
        req('STRUCTURED_METADATA_REGRESSION_PASS' in rr.stdout,'structured metadata regression did not pass')
    except Exception as e: errors.append('structured metadata Java test failed: '+str(e))

# ---------- Vehicle model manifest + SHA/signature + unique sources ----------
manifest=json.loads(txt(ASSETS/'vehicle_model_manifest.json'))
req(manifest.get('version')=='7.3.1','vehicle_model_manifest version must be 7.3.1')
car_src=txt(JAVA/'CarCatalog.java')
car_re=re.compile(r'new CarItem\("([^"]+)","([^"]+)","([^"]+)",true\)')
cars={m.group(1):(m.group(2),m.group(3)) for m in car_re.finditer(car_src)}
req(len(cars)==6,'expected exactly 6 supported built-in cars')
req(set(manifest.get('cars',{}))==set(cars),'vehicle model cars differ from CarCatalog')
manifest_files=[]
for cid,(name,sig) in cars.items():
    o=manifest['cars'].get(cid,{})
    sources=o.get('sources',[])
    req(o.get('source_count')==len(sources),f'{cid}: source_count mismatch')
    req(len(sources)>=3,f'{cid}: fewer than 3 calibration sources')
    hashes=[x.get('sha256','') for x in sources]
    req(len(set(hashes))==len(hashes),f'{cid}: duplicate SHA-256 calibration source would overweight median')
    mp=ASSETS/o.get('asset','')
    req(mp.is_file(),f'{cid}: model binary missing')
    if mp.is_file():
        req(sha(mp)==o.get('sha256'),f'{cid}: model SHA mismatch')
        req(sig.encode() in mp.read_bytes(),f'{cid}: model car signature missing')
        manifest_files.append((cid,name,sig,mp,'model'))
    for x in sources:
        p=ASSETS/x.get('asset','')
        req(p.is_file(),f'{cid}: calibration file missing {x.get("asset")}')
        if p.is_file():
            req(sha(p)==x.get('sha256'),f'{cid}: calibration SHA mismatch {x.get("name")}')
            req(p.stat().st_size==x.get('bytes'),f'{cid}: calibration byte size mismatch {x.get("name")}')
            req(sig.encode() in p.read_bytes(),f'{cid}: calibration signature mismatch {x.get("name")}')
            manifest_files.append((cid,name,sig,p,'source'))

# The stray BMW spa_041 file is deliberately not a model source if its binary signature is not our built-in BMW signature.
for p in (ASSETS/'calibration_sources').rglob('*.carsetup'):
    # Non-manifest files are allowed only as quarantined research inputs; they must never be referenced by the manifest.
    pass

# ---------- Codec identity/no-op runtime test on EVERY manifest model+source ----------
with tempfile.TemporaryDirectory(prefix='acevo_codec_') as td:
    td=Path(td); out=td/'out';out.mkdir(); test=td/'CodecVerifier.java'
    test.write_text(textwrap.dedent(r'''
        import com.greenbuddy.acevosetupengineer.*;
        import java.nio.file.*; import java.util.*;
        public class CodecVerifier {
          public static void main(String[] a) throws Exception {
            if(a.length!=4) throw new IllegalArgumentException("id name sig file");
            byte[] b=Files.readAllBytes(Paths.get(a[3]));
            if(!LiveCarSetupCodec.signatureMatches(b,a[0],a[2])) throw new RuntimeException("signature mismatch");
            LiveSetupSpec s=LiveCarSetupCodec.decode(b,a[0],a[1],a[2]);
            float[] p=s.pressure.clone(); byte[] z=LiveCarSetupCodec.patch(b,s,a[2]);
            if(!Arrays.equals(b,z)) throw new RuntimeException("identity patch changed bytes");
            LiveSetupSpec r=LiveCarSetupCodec.decode(z,a[0],a[1],a[2]);
            for(int i=0;i<4;i++) if(Math.abs(p[i]-r.pressure[i])>0.0001f) throw new RuntimeException("pressure changed");
            SetupValidator.Result v=SetupValidator.check(r); if(!v.ok) throw new RuntimeException(v.text());
            System.out.println("CODEC_PASS");
          }
        }
    '''),encoding='utf-8')
    try:
        run(['javac','-encoding','UTF-8','-d',str(out),str(JAVA/'LiveSetupSpec.java'),str(JAVA/'LiveCarSetupCodec.java'),str(JAVA/'SetupValidator.java'),str(test)])
        for cid,name,sig,p,kind in manifest_files:
            rr=run(['java','-cp',str(out),'CodecVerifier',cid,name,sig,str(p)])
            req('CODEC_PASS' in rr.stdout,f'{cid} {p.name}: codec runtime failed')
        notes.append(f'codec identity/signature/pressure/validator PASS on {len(manifest_files)} manifest binaries')
    except Exception as e: errors.append('codec runtime verification failed: '+str(e))

# ---------- Multi-source builder determinism ----------
try:
    before={p.relative_to(ASSETS).as_posix():sha(p) for p in (ASSETS/'vehicle_models').glob('*.carsetup')}
    rr=run([sys.executable,str(ROOT/'tools/build_vehicle_models.py')])
    after={p.relative_to(ASSETS).as_posix():sha(p) for p in (ASSETS/'vehicle_models').glob('*.carsetup')}
    req(before==after,'vehicle model builder is not deterministic')
except Exception as e: errors.append('vehicle model builder failed: '+str(e))

# ---------- Pure-Java logic test with stub model store ----------
with tempfile.TemporaryDirectory(prefix='acevo_logic_') as td:
    td=Path(td); pkg=td/'com/greenbuddy/acevosetupengineer';pkg.mkdir(parents=True);out=td/'out';out.mkdir()
    (pkg/'VehicleModelStore.java').write_text(textwrap.dedent(r'''
      package com.greenbuddy.acevosetupengineer;
      import java.util.*;
      public final class VehicleModelStore {
        public static final class Model { public String carId; public LiveSetupSpec center; public final List<LiveSetupSpec> calibration=new ArrayList<>(); }
        private final Map<String,Model> m=new HashMap<>(); public void put(String id,Model x){m.put(id,x);} public boolean supports(String id){return m.containsKey(id);}
        public Model load(String id,String n,String s){return m.get(id);}
      }
    '''),encoding='utf-8')
    (pkg/'LiveUpdateManager.java').write_text('package com.greenbuddy.acevosetupengineer; public final class LiveUpdateManager { public static final class LiveState { public boolean newerThanEmbedded=false,genericPhysicsChanges=false; } }',encoding='utf-8')
    (pkg/'LogicVerifier.java').write_text(textwrap.dedent(r'''
      package com.greenbuddy.acevosetupengineer;
      import java.util.*;
      public final class LogicVerifier {
        static LiveSetupSpec s(String id,float d){ LiveSetupSpec x=new LiveSetupSpec();x.carId=id;x.carName=id;x.trackToken="mount_panorama_gp";x.trackLabel="Mount Panorama";x.brakeBias=60+d;x.diffPreload=100+d*10;x.fuel=30;for(int i=0;i<4;i++){x.pressure[i]=24+i*.1f;x.camber[i]=-3+d*.1f;x.toe[i]=.05f+d*.01f;x.spring[i]=100000+d*1000;x.bumpstopRange[i]=.02f+d*.001f;x.bumpstopRate[i]=100000+d*1000;x.slowBump[i]=10000+d*100;x.fastBump[i]=8000+d*100;x.slowRebound[i]=12000+d*100;x.fastRebound[i]=9000+d*100;}x.arb[0]=40000+d*1000;x.arb[1]=30000+d*1000;x.rideHeight[0]=55+d;x.rideHeight[1]=75+d;x.tcPresent=true;x.tc=5+d;x.absPresent=true;x.abs=5+d;return x; }
        static VehicleModelStore.Model model(String id){VehicleModelStore.Model m=new VehicleModelStore.Model();m.carId=id;m.calibration.add(s(id,-1));m.calibration.add(s(id,0));m.calibration.add(s(id,1));m.center=s(id,0);return m;}
        public static void main(String[] a)throws Exception{
          VehicleModelStore store=new VehicleModelStore();VehicleModelStore.Model selected=model("ford_mustang_gt3"), bmw=model("bmw_m4_gt3_evo"), por=model("porsche_992_gt3_r_rennsport");store.put(selected.carId,selected);store.put(bmw.carId,bmw);store.put(por.carId,por);
          List<LiveTrackFusion.Observation> obs=Arrays.asList(new LiveTrackFusion.Observation(bmw.carId,s(bmw.carId,1)),new LiveTrackFusion.Observation(bmw.carId,s(bmw.carId,.5f)),new LiveTrackFusion.Observation(por.carId,s(por.carId,-1)));
          LiveTrackFusion.Result f=LiveTrackFusion.apply(selected,obs,store);if(f.cars!=2||f.samples!=3)throw new RuntimeException("fusion counts");
          if(f.spec.pressure[0]!=selected.center.pressure[0]||f.spec.fuel!=selected.center.fuel||f.spec.tc!=selected.center.tc)throw new RuntimeException("cross-car pressure/fuel/electronics changed");
          List<LiveTrackFusion.Observation> one=Collections.singletonList(new LiveTrackFusion.Observation(bmw.carId,s(bmw.carId,1)));LiveTrackFusion.Result withheld=LiveTrackFusion.apply(selected,one,store);if(withheld.fieldsFused!=0)throw new RuntimeException("single-car target signal should be withheld");
          for(String v:new String[]{"SAFE","STABLE_LONGRUN","FAST_CONTROL","HOTLAP_ATTACK"}){LiveSetupSpec base=f.spec.copy();base.carId=selected.carId;base.trackToken="mount_panorama_gp";LiveSetupSpec z=LiveEngineeringV7.build(base,v,selected,false,new LiveUpdateManager.LiveState());for(int i=0;i<4;i++)if(z.pressure[i]!=base.pressure[i])throw new RuntimeException("variant pressure changed");LiveFineTuningV7.Result q=LiveFineTuningV7.apply(z,LiveFineTuningV7.PROBLEMS[1],3,selected);for(int i=0;i<4;i++)if(q.spec.pressure[i]!=base.pressure[i])throw new RuntimeException("fine pressure changed");EngineeringSelfAuditV73.Result ar=EngineeringSelfAuditV73.verify(z,q.spec,v,selected,false);if(!ar.ok)throw new RuntimeException(ar.text());}
          System.out.println("LOGIC_RUNTIME_PASS");
        }
      }
    '''),encoding='utf-8')
    actual=[JAVA/'LiveSetupSpec.java',JAVA/'SetupValidator.java',JAVA/'CarCatalog.java',JAVA/'LiveTrackFusion.java',JAVA/'LiveEngineeringV7.java',JAVA/'LiveFineTuningV7.java',JAVA/'EngineeringSelfAuditV73.java']
    try:
        run(['javac','-encoding','UTF-8','-d',str(out),*map(str,actual),str(pkg/'VehicleModelStore.java'),str(pkg/'LiveUpdateManager.java'),str(pkg/'LogicVerifier.java')])
        rr=run(['java','-cp',str(out),'com.greenbuddy.acevosetupengineer.LogicVerifier'])
        req('LOGIC_RUNTIME_PASS' in rr.stdout,'logic runtime test did not pass')
    except Exception as e: errors.append('logic runtime verification failed: '+str(e))

# ---------- Source-level safeguards ----------
fusion=txt(JAVA/'LiveTrackFusion.java'); fine=txt(JAVA/'LiveFineTuningV7.java'); eng=txt(JAVA/'LiveEngineeringV7.java'); audit=txt(JAVA/'EngineeringSelfAuditV73.java')
req('carSignals.size()<2' in fusion,'target-layout fusion does not require >=2 distinct cars per field')
req('perCar.computeIfAbsent' in fusion and 'median(carSignals)' in fusion,'target-layout aggregation median architecture missing')
req('s.pressure' not in '\n'.join(x for x in fusion.splitlines() if '=' in x and 'pressure' in x),'LiveTrackFusion writes pressure')
req('Fuel, pressure and wing remain' in eng,'variant no-invent fuel/pressure guard note missing')
req('/3f' in fine and 'quantile' in fine,'fine-tuning observed quantile interpolation missing')
req('Magic-Deltas' in fine or 'Keine festen Setup-Deltas' in fine,'fine-tuning no-magic-delta evidence missing')
req('outside verified same-car calibration range' in audit,'post-calculation range gate missing')

# ---------- Private key exclusion ----------
keys=list(ROOT.rglob('*.jks'))+list(ROOT.rglob('*.keystore'))
req(not keys,'private keystore present in source bundle: '+', '.join(map(str,keys)))

if errors:
    print('VERIFICATION_v7.3.1: FAIL')
    for e in errors: print('ERROR:',e)
    sys.exit(1)
print('VERIFICATION_v7.3.1: PASS')
print('tracks=36; cars=6; manifest_binaries=',len(manifest_files))
for n in notes: print('NOTE:',n)
