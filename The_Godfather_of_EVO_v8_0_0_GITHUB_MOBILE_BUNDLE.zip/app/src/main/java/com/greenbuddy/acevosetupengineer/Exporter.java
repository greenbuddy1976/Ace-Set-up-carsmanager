package com.greenbuddy.acevosetupengineer;

import android.content.*;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.OutputStream;

public final class Exporter {
    private Exporter(){}
    public static Uri save(Context c, byte[] data, String name) throws Exception {
        ContentValues v=new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
        v.put(MediaStore.MediaColumns.MIME_TYPE,"application/octet-stream");
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS+"/The_Godfather_of_EVO");
        v.put(MediaStore.MediaColumns.IS_PENDING,1);
        ContentResolver r=c.getContentResolver();
        Uri u=r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
        if(u==null) throw new IllegalStateException("Zieldatei konnte nicht angelegt werden.");
        try(OutputStream out=r.openOutputStream(u,"w")){
            if(out==null) throw new IllegalStateException("Zieldatei konnte nicht geöffnet werden.");
            out.write(data); out.flush();
        } catch(Exception e){ r.delete(u,null,null); throw e; }
        v.clear();v.put(MediaStore.MediaColumns.IS_PENDING,0);r.update(u,v,null,null);
        return u;
    }
}
